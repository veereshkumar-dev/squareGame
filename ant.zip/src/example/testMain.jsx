import React from 'react'

const TestMain = () => {
  return (
    <>
      <h2>hello main</h2>
    </>
  )
}

export default TestMain
