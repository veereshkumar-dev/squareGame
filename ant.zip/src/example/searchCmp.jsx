import React from 'react'

const SearchCmp = () => {
  return (
    <div>search</div>
  )
}

export default SearchCmp
