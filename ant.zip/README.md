# Single page project based on Webpack5, React17, React-router v6, Antd4.x, Less, Sass

## Building and running on localhost

First install dependencies:

```sh
yarn
```

To run in hot module reloading mode:

```sh
yarn start
```

To create a production build:

```sh
yarn build
```

## Running

Open the file `dist/index.html` in your browser
