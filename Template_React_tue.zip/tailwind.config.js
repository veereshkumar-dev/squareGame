module.exports = {
  darkMode: 'media',
  purge: [
    './src/**/*.ts',
    './src/**/*.tsx',
    './src/**/*.html',
    './public/index.html',
  ],
  theme: {},
  variants: {},
  plugins: [],
};
