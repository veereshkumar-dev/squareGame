import * as React from 'react';
import './styles/popup.css'
import AppStore from './AppStore';

export interface IPopupProps {
}

import { observer } from 'mobx-react';

@observer
export default class Popup extends React.Component<IPopupProps> {
    public render() {
        return (

            <div className={
                "popupContainer absolute flex flex-col border-2 overflow-hidden "
                + (AppStore.popupVisible ? " " : " hidden ")
            }
            
            onMouseLeave={()=>{
                //console.log('1')
                //AppStore.hidePopup()
            }}
            >
                {AppStore.allCDEs.map(item=>{
                    return <div className="popupItem"
                    key={item}
                        onClick={()=>{
                            let start = AppStore.selectionStart;
                            let end = AppStore.selectionEnd

                            if (start != end) {

                                if(start>end){
                                    let tmp = end;
                                    end = start;
                                    start = tmp
                                }                                   
                                let cde ='Price Escalation';
                                let text = window.getSelection().toString().substring(0,200)
                                
                                AppStore.hidePopup()            
                                AppStore.addAnnotation(item, AppStore.selectionText,  AppStore.annotationID, start, end)
                            }
                        }}
                    >
                        {item}
                    </div>
                })}

            </div>
        );
    }
}
