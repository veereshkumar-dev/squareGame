import {
    observable,
    computed,
    action,
    makeAutoObservable,
    get,
    toJS,
} from 'mobx';


import _log from 'ololog';
let log = _log.configure({
    locate: false,
    time: false,
    stringify: {
        pure: false,
        json: true,
        maxDepth: 5,
        maxLength: 50,
        maxArrayLength: 60,
        maxObjectLength: 200,
        maxStringLength: 60,
        precision: 2,
        formatter: undefined,
        pretty: 'auto',
        rightAlignKeys: true,
        fancy: true,
        indentation: ' ',
    },
});

export {log}
//Initialization on window object


// Loaded via <script> tag, create shortcut to access PDF.js exports.
var pdfjsLib = window['pdfjs-dist/build/pdf'];
// The workerSrc property shall be specified.
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://mozilla.github.io/pdf.js/build/pdf.worker.js';


import * as _ from 'underscore';

interface StringIndexer {
    [key: string]: string | undefined;
}

class AppStore {

    constructor() {
        makeAutoObservable(this);
    }
    
    server='http://192.168.55.107:8080'

    @observable userPref = {
        showInfo: false,
        showCDE: true,
        showAnnotations: true,
    }

    @action
    userPrefToggle(key) {
        this.userPref[key] = !this.userPref[key]
    }

    @observable popupVisible = false
    @action
    showPopup = ()=>{
        this.popupVisible = true;

    }
    hidePopup = ()=>{
        this.popupVisible=false;
    }

    @observable annotations = [

    ]

    @action
    updateText(){
        this.currentTextURL = this.server + '/robots.txt'
        this.currentPDFURL = this.server + '/ses-dg.pdf'        
    }

    annotationID = 1
    @action
    getNextAnnotationID = () => {
        this.annotationID += 1;
        return this.annotationID;
    }

    @action
    addAnnotation = (cde: string, text: string, annotationID, start: number, end: number) => {
         
        let instance = new window['Mark'](document.getElementById('front'))
        instance.markRanges([{
            start: start,
            length: end - start
        }]);

        this.annotations.push({
            cde: cde,
            text: text,
            annotationID: annotationID,
            start:start,
            end:end
        })
    }

    @computed
    get annotations_reverse() {
        return this.annotations.slice().reverse()
    }


    @observable currentPDFURL = this.server+'/A17_FlightPlan.pdf';
    @observable currentTextURL = this.server+'/small.txt';

    @observable pdfContent = null
    @observable textContent:string = ''

    @action
    updateContract(pdfURL, textURL){
        this.currentPDFURL = pdfURL
        this.currentTextURL = textURL

    }

    selectionStart:number=0
    selectionEnd:number=0
    selectionText:string=''

    @action
    setSelection = (start:number, end:number, text:string)=>{
        this.selectionStart = start 
        this.selectionEnd = end 
        this.selectionText = text 

    }
    

    pageSplitIndices:number[] = []
    @action
    addPageSplitIndex = (index:number)=>{
        this.pageSplitIndices.push(index)
    }

    @observable selectedCDEs = [
        'Price Escalation',
        'Status',
        'Effective Date'
    ]


    @observable allCDEs = [
        'Price Escalation',
        'Status',
        'Effective Date',
        'op1',
        'op2'
    ]

 

}



export default new AppStore();