import * as React from 'react';
import './styles/app.css'


export interface IAppProps {
}

import {
    action,
    computed,
    makeAutoObservable,
    makeObservable,
    observable,
    toJS
} from 'mobx';
import { observer } from 'mobx-react';

import PDFSection from './PDFSection';
import TextSection from './TextSection';
import SidePannel from './SidePannel/SidePannel';
import AppStore from './AppStore';
import Popup from './Popup';


window['AppStore'] = AppStore

class Store {
    constructor() {
        makeAutoObservable(this);
    }

   
    init(){}
}


@observer
export default class App extends React.Component<IAppProps> {
    store = new Store()

    componentDidMount() {
        this.store.init()       
    }

    public render() {
        return (
            <div className="flex w-full">
                <PDFSection AppStore={AppStore} currentPDFURL={AppStore.currentPDFURL}/>
                <TextSection AppStore={AppStore} currentTextURL={AppStore.currentTextURL}/>
                <SidePannel AppStore={AppStore}/>

                <Popup/>
            </div>
          );
    }
}
