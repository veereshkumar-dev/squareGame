import * as React from 'react';
import './styles/textSection.css'

var $ = window['jQuery']

export interface ITextSectionProps {
    AppStore: any,
    currentTextURL: string
}

import {
    action,
    computed,
    makeAutoObservable,
    makeObservable,
    observable,
    toJS
} from 'mobx';
import { observer } from 'mobx-react';
import AppStore from './AppStore';



class Store {
    constructor() {
        makeAutoObservable(this);
    }

    @observable pdfObj: any = null

    @observable textContent = 'loading text..'
    @observable show = false;
    @observable text = 'loadin';
    pageNumber = 1;
    totalPages = Array(600).fill().map((element, index) => index + 1);


    init() {

    }

}

@observer
export default class TextSection extends React.Component<ITextSectionProps> {
    store = new Store()

    componentDidMount() {
        this.store.init()
        fetch(this.props.currentTextURL).then((r) => {
            r.text().then((d) => {
                let CONTENT = d;

                this.store.textContent = d.substring(0, 40000)


                var regex = /-->/gi, result, indices = [];
                while ((result = regex.exec(this.store.textContent))) {
                    AppStore.addPageSplitIndex(result.index);
                }

                console.log(AppStore.pageSplitIndices)
            })
        })


    }

    componentDidUpdate() {
        fetch(this.props.currentTextURL).then((r) => {
            r.text().then((d) => {
                let CONTENT = d;

                this.store.textContent = d.substring(0, 40000)
            })
        })
    }


    public render() {
        return (
            <div id='textSectionWrapper' className="w-1/2 textSectionWrapper flex relative overflow-x-hidden overflow-y-scroll">
                <div className=" textSection w-full h-screen bg-white text-center items-center">
                    <div className="textContainer   flex flex-col w-full overflow-auto" >
                        {/* <textarea name="" className="h-screen" id="textarea" readOnly={true} value={this.store.textContent}
                       onMouseUp={()=>{
                        $("#textarea").focus();
                        var sel = $("#textarea").getSelection();
                        console.log(sel.start + ", " + sel.end);
                       }}
                       >
                           
                       </textarea> */}

                        <div id="front" className=" p-8 text-left">{this.store.textContent}</div>
                        <div id="back" className=" p-8 text-left"

                            onMouseUp={(e) => {
                                let start = window.getSelection().anchorOffset;
                                let end = window.getSelection().focusOffset
                                let text = window.getSelection().toString().substring(0, 200);

                                AppStore.setSelection(start, end, text)

                                //console.log(start, end)

                                if (start != end) {

                                    // if(start>end){
                                    //     let tmp = end;
                                    //     end = start;
                                    //     start = tmp
                                    // }                                   
                                    // let cde ='Price Escalation';
                                    // let text = window.getSelection().toString().substring(0,200)


                                    // $(".popupContainer").fadeIn("fast");
                                    $(".popupContainer").css("top", e.pageY);
                                    $(".popupContainer").css("left", e.pageX);

                                    AppStore.showPopup()


                                    //AppStore.addAnnotation(cde, text,  AppStore.annotationID, start, end)
                                }

                            }}

                        >{this.store.textContent}</div>
                    </div>

                </div>
                {/* <div className="textSection w-1/2 bg-blue-600 m-auto text-center">
                    <button className="w-1/2 m-2 border-2" onClick={() => {

                    }}>Whats in VIEWPOR33T</button>
                </div> */}
            </div>
        );
    }
}
