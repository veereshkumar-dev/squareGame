import { observer } from 'mobx-react';
import * as React from 'react';
import AppStore from '../AppStore';
import './styles/annotationsSection.css'


export interface IAnnotationSectionProps {
  AppStore: any
}

@observer
export default class AnnotationSection extends React.Component<IAnnotationSectionProps> {
  public render() {
    return (
      <div className={"annotationSection flex w-full flex-col flex-grow "
        + ((AppStore.userPref.showInfo && AppStore.userPref.showCDE) ? " maxHeight50 "
        : (AppStore.userPref.showInfo != AppStore.userPref.showCDE ? " maxHeight75 " : " maxHeight95 "))
        // + (this.props.AppStore.userPref.showAnnotations? " h-full ": " ")
      }  >

        <div className="header w-full h-6 "
          onClick={() => { this.props.AppStore.userPrefToggle('showAnnotations') }}
        >
          Annotations
        </div>
        <div className="flex flex-col content  w-full flex-grow-1 m-auto h-full overflow-y-scroll ">
          {AppStore.annotations_reverse.map((item, num) => {
            return (
              <div key={num} className=" annotationItem flex flex-col p-2 mt-2 mb-2 ml-3 mr-3 "
                onClick={() => {
                  $('#anno_id_' + (item.annotationID))[0].scrollIntoView({ behavior: 'smooth', block: 'center' })
                }}
              >
                <div className="title font-medium text-sm">{item.annotationID + '-' + item.cde}</div>
                <div className="content text-xs">{item.text}</div>
              </div>
            )
          })}
        </div>
      </div>
    );
  }
}
