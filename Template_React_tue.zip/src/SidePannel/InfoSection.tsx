import { observer } from 'mobx-react';
import * as React from 'react';
// import AppStore from 'src/AppStore';
// import './styles/infoSections.css'

export interface IInfoSectionProps {
  AppStore: any
}

@observer
export default class InfoSection extends React.Component<IInfoSectionProps> {
  public render() {
    return (

      <div className={"infoSection flex  flex-col flex-grow-1 w-full "
      }
      >

        <div className="header w-full h-6 "
          onClick={() => { this.props.AppStore.userPrefToggle('showInfo') }}
        >
          Contract Info
        </div>
        <div className={"flex content w-full flex-grow-1 m-auto h-full "
          + (this.props.AppStore.userPref.showInfo ? " " : " hidden ")

        }
        >
          Contenth
        </div>

      </div>

    );
  }
}
