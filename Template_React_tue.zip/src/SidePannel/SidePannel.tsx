import * as React from 'react';
import AnnotationSection from './AnnotationsSection';
import CDESection from './CDESection';
import InfoSection from './InfoSection';
import '../styles/sidePannel.css'


export interface ISidePannelProps {
  AppStore: any
}

export default class SidePannel extends React.Component<ISidePannelProps> {
  public render() {
    const {
      AppStore
    } = this.props;

    return (
      <div className="sidePannel flex flex-col h-screen w-1/5">
        <InfoSection AppStore={AppStore} />
        <CDESection AppStore={AppStore} />
        <AnnotationSection AppStore={AppStore} />
      </div>
    );
  }
}
