import { observer } from 'mobx-react';
import * as React from 'react';
import AppStore from '../../src/AppStore';
import {log} from '../../src/AppStore';
// import './styles/cdeSection.css'


export interface ICDESectionProps {
  AppStore: any
}

@observer
export default class CDESection extends React.Component<ICDESectionProps> {
  public render() {
    return (
      <div className={"cdeSection flex w-full  flex-col  "
      }      >

        <div className="header w-full h-6 "
          onClick={() => { this.props.AppStore.userPrefToggle('showCDE') }}
        >
          CDE Selection
        </div>
        <div className={"flex content w-full flex-col flex-grow-1 m-auto h-full "
          + (this.props.AppStore.userPref.showCDE ? " " : " hidden ")

        }
        >
          {AppStore.allCDEs.map(item => {
            return <div className="flex">
              <input type="checkbox" name="" id="" 
                onClick={(e)=>{
                  log(e.target.checked)
                }}
              />
              <span>{item}</span>
            </div>
          })}
        </div>
      </div>
    );
  }
}
