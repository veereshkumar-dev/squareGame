import * as React from 'react';
declare module 'react-read-pdf'

export interface PDFSectionProps {
  className?: string;
  children?: React.ReactNode;
}

export function PDFSection(props: PDFSectionProps): React.ReactNode;
