import React, { Component } from 'react';
import './PDFSection.scss';

import { Document, Page } from 'react-pdf';
import { pdfjs } from 'react-pdf';
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

import $ from 'jquery';

import {
  action,
  computed,
  makeAutoObservable,
  makeObservable,
  observable,
} from 'mobx';
import { observer } from 'mobx-react';


import Lib from '../Lib';
const { log, AppStore, _ } = Lib;

class Store {
  constructor() {
    makeAutoObservable(this);
  }

  @observable show = false;
  @observable text = 'loadin';
  @observable pageNumber = 1;

  @action
  changePagen() {
    //    this.pageNumber = 2;
  }
  @action
  showComponent() {
    log(9999);
    this.show = true;

    setTimeout(() => {}, 2000);
  }
}

@observer
export default class PDFSection extends Component {
  store = new Store();

  getViewPercentage = (element) => {
    const viewport = {
      top: window.pageYOffset,
      bottom: window.pageYOffset + window.innerHeight,
    };

    const elementBoundingRect = element.getBoundingClientRect();
    const elementPos = {
      top: elementBoundingRect.y + window.pageYOffset,
      bottom:
        elementBoundingRect.y + elementBoundingRect.height + window.pageYOffset,
    };

    if (viewport.top > elementPos.bottom || viewport.bottom < elementPos.top) {
      return 0;
    }

    // Element is fully within viewport
    if (viewport.top < elementPos.top && viewport.bottom > elementPos.bottom) {
      return 100;
    }

    // Element is bigger than the viewport
    if (elementPos.top < viewport.top && elementPos.bottom > viewport.bottom) {
      return 100;
    }

    const elementHeight = elementBoundingRect.height;
    let elementHeightInView = elementHeight;

    if (elementPos.top < viewport.top) {
      elementHeightInView =
        elementHeight - (window.pageYOffset - elementPos.top);
    }

    if (elementPos.bottom > viewport.bottom) {
      elementHeightInView =
        elementHeightInView - (elementPos.bottom - viewport.bottom);
    }

    const percentageInView = (elementHeightInView / window.innerHeight) * 100;

    return Math.round(percentageInView);
  };

  findHigestNumber = (nums)=> {
	
    let inputs = nums.filter((val, i) => nums.indexOf(val) === i)
    let max = inputs.length - 1;
    let min = 0;
  
    for(let i = 0; i < inputs.length; i++) {
        
        if(inputs[i] > max) max = inputs[i];
        if(inputs[i] < min) min = inputs[i];
    }
    
     return max + (-min);
  }

  componentDidMount() {
    window.$ = $;
    log('injectedJquery');
    window.log = log;
    log('injected log');
    window._ = _;
    log('injected uderscore');

    setInterval(() => {
      let pagesInViewport = []
      $('.pdfPage').map((index,item) => {
        pagesInViewport.push(this.getViewPercentage((item)));
      });
      //log(pagesInViewport)
      AppStore.setaAtivePage(pagesInViewport.reduce((iMax, x, i, arr) => x > arr[iMax] ? i : iMax, 0))
    }, 500);
  }

  public render() {
    return (
      <div
        className={
          (this.store.show ? ' uk-animation-slide-bottom-small ' : ' uk-invisible ') +
          'pdfSection uk-width-3-4  flex flex-col  h-screen'
        }
      >
        {/* Page = {AppStore.activePage} */}
        <Document
          //renderMode="svg"
          file={AppStore.contractPdfURL}
          onLoadSuccess={(pdf) => {
            log('loaded');
            //log(pdf.numPages )
            AppStore.setTotalPages(pdf.numPages);

            setTimeout(() => {
              this.store.showComponent();
            }, 1500);
          }}
        >
          {_.range(0, AppStore.totalPages, 1).map((currPage) => {
            return (
              <Page
                className="pdfPage"
                pageNumber={currPage + 1}
                scale={1.5}
                renderTextLayer={false}
                ons
              />
            );
          })}
        </Document>
      </div>
    );
  }
}
