import React, { Component } from 'react';
import './TextSection.scss';
import {
  action,
  computed,
  makeAutoObservable,
  makeObservable,
  observable,
} from 'mobx';
import { observer } from 'mobx-react';

import ViewportList from 'react-viewport-list';

import Lib from '../Lib';
import Word from '../Word';
const { log, AppStore, _ } = Lib;

class Store {
  constructor() {
    makeAutoObservable(this);
  }

  @observable show = false;
  @observable oveflowShown = false;

  @action
  showComponent() {
    setTimeout(() => {
      this.show = true;

      setTimeout(() => {
        this.oveflowShown = true;
      }, 800);
    }, 1000);
  }
}

@observer
export default class TextSection extends Component {
  store = new Store();

  componentDidMount() {
    fetch('http://192.168.1.36:3000/getNextContract')
    .then((response) => {
      return response.json();
    })
    .then((response) => {
      response = response[0];
      log(response)
      AppStore.set_allCDEs(response);

      var cdes = _.filter(
        _.map(_.keys(response), (item) => {
          if (item.includes('cde_')) {
            return log(item.split('cde_')[1].replace('_', ' '));
          } else {
            return null;
          }
        }),
      );

      log("cdes", cdes)

      let contract = {
        contractID: response.contractID,
        pdfURL: response.pdfURL,
        textURL: response.textURL,

        contractParty1: response.contractParty1,
        contractParty2: response.contractParty2,
      };

      AppStore.set_conractInfo(contract);

      let annotations =[]
      AppStore.clear_annotations()
      if(response.JSONOutput.length>0){

         annotations = JSON.parse(response.JSONOutput);
         log("annotations", annotations)
    }
     

      fetch(AppStore.contractTextURL)
        .then((response) => response.text())
        .then((response) => {
          //log(response)
          AppStore.set_fullText(response);
          window.text = response;
          AppStore.pageLoaded = true;

          if(annotations.length>0){
            AppStore.set_annotations(annotations)
          }

          this.store.showComponent()
        });
    });
  }

  public render() {
    return (
      <div
        className={
          (this.store.show ? '' : ' uk-invisible ') +
          'textSection uk-width-3-6 flex flex-col h-screen  '
        }
      >
        {/* <div className="invisible">{AppStore.activePageNumber}</div> */}
        <div
          id={'textContainer'}
          className={
            (this.store.show
              ? ' uk-animation-slide-bottom-small '
              : ' uk-invisible ') +
            // (this.store.oveflowShown
            //   ? ' overflow-y-scroll  '
            //   : ' overflow-hidden ') +
            ' spanSection uk-animation  overflow-y-scroll   p-8 '
          }
        >
          {/* <VirtualList items={AppStore.textSplit}/> */}

          {_.map(AppStore.textSplit, (text: string, index: number) => {
            let checkHighlight = AppStore.checkHighlight(index);
            let isNotOnCurrentPage = checkHighlight == 'notOnCurrentPage';
            let isPageStart = checkHighlight.includes('pageStart');
            let pageNumber = isPageStart
              ? checkHighlight.split('pageNumber')[1]
              : 0;
            if (!isNotOnCurrentPage) {
              return (
                <Word
                  key={index}
                  index={index}
                  checkHighlight={checkHighlight}
                  isPageStart={isPageStart}
                  pageNumber={parseInt(pageNumber.toString())}
                  text={text}
                />
              );
            } else {
              return null;
            }
          })}
        </div>
      </div>
    );
  }
}
