import React, { Component } from 'react';

import {
  action,
  computed,
  makeAutoObservable,
  makeObservable,
  observable,
} from 'mobx';
import { observer } from 'mobx-react';
import LinesEllipsis from 'react-lines-ellipsis';

import './SidePannel.scss';

import Lib from '../Lib';
import SelectCDE from '../SelectCDE';
const { log, AppStore } = Lib;

class Store {
  constructor() {
    makeAutoObservable(this);
  }

  @observable show = false;
  @observable text = 'loadin';
  @observable pageNumber = 1;

  @action
  changePagen() {
    this.pageNumber = 4;
  }
  @action
  showComponent() {
    log(9999);
    this.show = true;

    setTimeout(() => {
      AppStore.goToNextPage();
    }, 2000);
  }
}

@observer
export default class SidePannel extends Component {
  store = new Store();

  componentDidMount() {
    fetch('http://192.168.1.36:3000/getNextContract').then((response) => {
      log(response);
    });

  


    // let headers = {
    //   method:  'GET',
    //   headers: {
    //   "Access-Control-Allow-Origin":"*",
    //   'Cache-Control': 'no-cache',
    //   'Content-Type': 'application/json'
    //   },
    //   }
    //   fetch('http://192.168.1.36/getNextContract', headers)
    //   .then((response) => {
    //    log(response);
    //   })

    // .then((response) => response.text())
    // .then((response) => {
    //   //log(response)
    //   AppStore.set_fullText(response);
    //   window.text = response;
    //   AppStore.pageLoaded = true;
    // });
  }

  componentDidUpdate() {}

  public render() {
    return (
      <div className="sidePannel uk-width-1-2 h-screen  ">
        <div className="metadata  flex  m-6 justify-between ">
          <div className="flex">Page: {AppStore.userName}</div>
          <div className="flex flex-col justify-between">
            <button
              className="uk-button uk-button-primary"
              onClick={() => {
                fetch('http://192.168.1.36:3000/getNextContract')
                  .then((response) => {
                    return response.json();
                  })
                  .then((response) => {
                    response = response[0];
                    log(response)
                    AppStore.set_allCDEs(response);

                    var cdes = _.filter(
                      _.map(_.keys(response), (item) => {
                        if (item.includes('cde_')) {
                          return log(item.split('cde_')[1].replace('_', ' '));
                        } else {
                          return null;
                        }
                      }),
                    );

                    log("cdes", cdes)

                    let contract = {
                      contractID: response.contractID,
                      pdfURL: response.pdfURL,
                      textURL: response.textURL,

                      contractParty1: response.contractParty1,
                      contractParty2: response.contractParty2,
                    };

                    AppStore.set_conractInfo(contract);

                    let annotations =[]
                    AppStore.clear_annotations()
                    if(response.JSONOutput.length>0){

                       annotations = JSON.parse(response.JSONOutput);
                       log("annotations", annotations)
                  }
                   

                    fetch(AppStore.contractTextURL)
                      .then((response) => response.text())
                      .then((response) => {
                        //log(response)
                        AppStore.set_fullText(response);
                        window.text = response;
                        AppStore.pageLoaded = true;

                        if(annotations.length>0){
                          AppStore.set_annotations(annotations)

                        }
                      });
                  });

                // try {
                //   let pageID =
                //     'pageStart' + (AppStore.activePageNumber + 1).toString();
                //   log(pageID);
                //   let elmnt = document.getElementById(pageID);
                //   elmnt.scrollIntoView();
                // } catch (error) {
                // } finally {
                //   setTimeout(() => {
                //     AppStore.goToNextPage();
                //   }, 700);
                // }
              }}
            >
              NExt
            </button>

            <button
              className="uk-button uk-button-primary"
              onClick={() => {
                fetch(
                  'http://192.168.1.36:3000/saveContractAnnotations/' +
                    AppStore.contractInfo.contractID,
                  {
                    headers: {
                      accept: '*/*',
                      'accept-language': 'en-US,en;q=0.9',
                      'content-type': 'application/json',
                      'sec-ch-ua':
                        '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
                      'sec-ch-ua-mobile': '?0',
                      'sec-fetch-dest': 'empty',
                      'sec-fetch-mode': 'cors',
                      'sec-fetch-site': 'none',
                    },
                    referrerPolicy: 'strict-origin-when-cross-origin',
                    body: JSON.stringify({
                      annotations: AppStore.annotations,
                      cdes: AppStore.allCDEs                      
                    }),
                    method: 'POST',
                    mode: 'cors',
                    credentials: 'omit',
                  },
                );

                // fetch("http://192.168.1.36:3000/saveContractAnnotations/", {
                //   method: 'POST',
                //   headers: {
                //       'Content-Type': 'application/json'
                //   },
                //   body: JSON.stringify(AppStore.annotations)
                // }).then((res) => res.json())
                // .then((data) => console.log(data))
                // .catch((err) => console.log(err))
              }}
            >
              Submit
            </button>

            <button
              className="uk-button uk-button-danger"
              onClick={() => {
                log('exported');

                fetch('http://192.168.1.36:3000/getNextContract')
                  .then((response) => {
                    return response.json();
                  })
                  .then((response) => {
                    response = response[0];

                    window.lop = response;
                    AppStore.set_allCDEs(response);

                    var cdes = _.filter(
                      _.map(_.keys(response), (item) => {
                        if (item.includes('cde_')) {
                          return log(item.split('cde_')[1].replace('_', ' '));
                        } else {
                          return null;
                        }
                      }),
                    );

                    let contract = {
                      contractID: response.contractID,
                      pdfURL: response.pdfURL,
                      textURL: response.textURL,

                      contractParty1: response.contractParty1,
                      contractParty2: response.contractParty2,

                      cdes: cdes,
                    };
                  });
              }}
            >
              Export
            </button>
          </div>

          <div className="flex ">
            <table className="uk-table uk-table-small bg-white m-0 uk-table-striped border-2">
              <tbody>
                <tr>
                  <td>ID</td>
                  <td>{AppStore.contractInfo.contractID}</td>
                </tr>
                <tr>
                  <td>SBG</td>
                  <td>AERO</td>
                </tr>
                <tr>
                  <td>Contract Party 1</td>
                  <td>{AppStore.contractInfo.contractParty1}</td>
                </tr>
                <tr>
                  <td>Contract Party 2</td>
                  <td>{AppStore.contractInfo.contractParty2}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <ul uk-accordion="collapsible: false">
          <li>
            <a className="uk-accordion-title" href="#">
              Select CDE
            </a>
            <div className="uk-accordion-content">
              <SelectCDE />
            </div>
          </li>
          <li>
            <a className="uk-accordion-title" href="#">
              Annotations
            </a>
            <div className="uk-accordion-content">
              <div className="uk-flex  border-2">
                {AppStore.pageLoaded ? (
                  <ul
                    id="fragments"
                    className="uk-list uk-list-striped uk-flex-1 overflow-y-scroll"
                  >
                    {AppStore.annotations.map((fragment) => {
                      log(fragment);
                      let selectedText = AppStore.getSelectedText(
                        fragment.start,
                        fragment.end,
                      );
                      //log(selectedText);
                      return (
                        <li
                          key={fragment.id}
                          className={
                            selectedText[0] == 'u'
                              ? ' uk-invisible '
                              : 'fragment  hover:bg-gray-200  p-4 cursor-pointer'
                          }
                        >
                          <div className="uk-flex">
                            <div
                              className="uk-flex uk-flex-1 uk-flex-column"
                              onClick={() => {
                                log(fragment.id.toString());
                                let elmnt = document.getElementById(
                                  fragment.id.toString(),
                                );
                                elmnt.scrollIntoView();

                                setTimeout(() => {
                                  let elmnt2 =
                                    $('.pdfPage')[fragment.pageNumber];
                                  elmnt2.scrollIntoView();
                                }, 1000);
                              }}
                            >
                              <div className="title">{fragment.title}</div>
                              <div className="selectedText  ">
                                {selectedText?.substr(0, 70) + '...'}
                              </div>
                            </div>
                            <div
                              className="uk-flex close hover:bg-red-500"
                              onClick={(e) => {
                                AppStore.removeAnnotation(fragment.ID);
                              }}
                            >
                              <div className="btn">x</div>
                            </div>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                ) : (
                  ''
                )}
              </div>
            </div>
          </li>
        </ul>
      </div>
    );
  }
}
