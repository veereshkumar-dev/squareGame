import {
  observable,
  computed,
  action,
  makeAutoObservable,
  get,
  toJS,
} from 'mobx';
import Source from './BotStore.json';
import * as _ from 'underscore';
import _log from 'ololog';
import { act } from 'react-dom/test-utils';
let log = _log.configure({
  locate: false,
  time: false,
  stringify: {
    pure: false,
    json: true,
    maxDepth: 5,
    maxLength: 50,
    maxArrayLength: 60,
    maxObjectLength: 200,
    maxStringLength: 60,
    precision: 2,
    formatter: undefined,
    pretty: 'auto',
    rightAlignKeys: true,
    fancy: true,
    indentation: ' ',
  },
});

interface StringIndexer {
  [key: string]: string | undefined;
}

class AppStore {
  constructor() {
    makeAutoObservable(this);
  }

  baseURL = 'http://192.168.1.36:3000/getFile/';
  @observable contractInfo = {
    contractID: '',
    pdfURL: '',
    textURL: '',

    contractParty1: '',
    contractParty2: '',

    cdes: [],
  };
  @action set_conractInfo(contract) {
    this.contractInfo = { ...contract };
    // this.contractInfo.contractID = contract.contractID
    // this.contractInfo.pdfURL = contract.pdfURL
    // this.contractInfo.textURL = contract.textURL
    // this.contractInfo.cdes = contract.cdes

    this.contractInfo;
  }
  @computed get contractTextURL() {
    return (
      this.baseURL +
      this.contractInfo.contractID +
      '/' +
      this.contractInfo.textURL
    );
  }
  @computed get contractPdfURL() {
    return (
      this.baseURL +
      this.contractInfo.contractID +
      '/' +
      this.contractInfo.pdfURL
    );
  }

  @observable userName = "kk"
  @action
  set_UserName = (userName:string) =>{
   this.userName  = userName
  }

  @observable fullText = ``;
  @observable activePageNumber: number = 0;
  // @observable activePage = 0;
  previousActivePage = -1;
  @action setaAtivePage = (activePage: number) => {
    this.activePageNumber = activePage;

    if (this.previousActivePage != activePage) {
      this.previousActivePage = activePage;

      try {
        let pageID = 'pageStart' + (activePage + 1).toString();
        let elmnt = document.getElementById(pageID);
        elmnt.scrollIntoView();
      } catch (error) {}
    }
  };

  @observable totalPages = 0;
  pages: string[] = [];

  @observable newStartPosition: number = -1;
  @observable newEndPosition: number = -1;

  //Toggles
  @observable pageLoaded = false;

  @observable textSplit: string[] = [];
  @observable pageText_List: any[] = [];

  @action setTotalPages = (numPages: number) => {
    this.totalPages = numPages;
  };

  @action
  goToNextPage = () => {
    log(this.activePageNumber);
    log(this.pageFragments.length);

    if (this.activePageNumber > this.pageFragments.length - 1) {
      return;
    }
    log('next');
    this.activePageNumber = this.activePageNumber + 1;

    //log(this.firstLinesOfPages[this.pageNumber - 1]);
  };

  @action
  goToPreviousPage = () => {
    if (this.activePageNumber < 1) {
      return;
    }
    log('prev');
    this.activePageNumber = this.activePageNumber - 1;

    //log(this.firstLinesOfPages[this.pageNumber - 1]);
  };

  @action
  set_fullText = (data: string) => {
    this.pageFragments.length = 0;
    this.pageBeginingIndex.length = 0;

    this.fullText = data;
    this.textSplit = data.split(' ');
    //this.pages = data.split(/\-\-\>\{\d+\}\<\-\-/)

    this.textSplit.map((word, index) => {
      if (word.includes('-->{')) {
        let pageBegining = parseInt(word.split('-->{')[1].split('}<--')[0]);
        this.pageBeginingIndex.push(index);
      }
    });

    log(this.pageBeginingIndex.toString());
  };

  @observable annotations = [
    // {
    //   ID: 1,
    //   title: 'Price Escalation',
    //   start: 25,
    //   end: 45,
    //   id: 'frag0',
    //   pageNumber: 1,
    // },
    // {
    //   ID: 2,
    //   title: 'Effective Date',
    //   start: 12,
    //   end: 16,
    //   id: 'frag1',
    //   selectedText: 'Highlight 2',
    //   pageNumber: 2,
    // },
    // {
    //   ID: 3,
    //   title: 'Price Escalation',
    //   start: 427,
    //   end: 444,
    //   id: 'frag2',
    //   pageNumber: 3,
    // },
    // {
    //   ID: 4,
    //   title: 'Price Escalation',
    //   start: 927,
    //   end: 954,
    //   id: 'frag3',
    //   pageNumber: 4,
    // },
    // {
    //   ID: 5,
    //   title: 'Price Escalation',
    //   start: 158,
    //   end: 170,
    //   id: 'frag4',
    //   pageNumber: 2,
    // },
  ];

  @action
  set_annotations = (annotations) => {
    this.annotations.length = 0;

    _.map(annotations, (item) => {
      this.annotations.push(item);
    });
  };

  @action
  clear_annotations = () => {
    log('clearin anno');

    this.annotations = [];
  };

  @computed get reverseAnnotations() {
    return toJS(this.annotations).reverse();
  }
  @action
  recordStart = (startIndex: number) => {
    this.newStartPosition = startIndex;
  };

  @action
  recordEnd = (endIndex: number) => {
    this.newEndPosition = endIndex;
  };

  newStartPosition_Mouse = -1;
  newEndPosition_Mouse = -1;
  @action
  recordStart_Mouse = (startIndex: number) => {
    this.newStartPosition_Mouse = startIndex;
  };

  @action
  recordEnd_Mouse = (endIndex: number) => {
    this.newEndPosition_Mouse = endIndex;
  };

  cache_getSelectedText: StringIndexer = {};
  getSelectedText = (start: number, end: number) => {
    let id = start + '-' + end;
    if (this.cache_getSelectedText[id]) {
      return this.cache_getSelectedText[id];
    } else {
      let selectedText = '';
      for (let i = start; i <= end; i++) {
        selectedText += this.textSplit[i] + ' ';
      }

      this.cache_getSelectedText[id] = selectedText;
      return selectedText;
    }
  };

  @action
  removeAnnotation = (ID: number) => {
    let index = _.findIndex(this.annotations, (item) => {
      return item.ID == ID;
    });

    log('ID ', ID);
    log('index ', index);
    log('annotations ', _.pluck(this.annotations, 'ID'));

    log('b4 remov ', _.pluck(this.annotations, 'ID'));

    this.annotations.splice(index, 1);

    log('afta remov ', _.pluck(this.annotations, 'ID'));
  };

  @action
  addAnnotation = (cde: string) => {
    log(cde);

    let nearestPage = -1;
    this.pageBeginingIndex.map((pageBeginingIndex, ind) => {
      if (this.newStartPosition < pageBeginingIndex) {
        nearestPage = ind;
        //log('-----', nearestPage)
      }
    });

    let allAnnotations = _.pluck(this.annotations, 'ID')
    let latestID  = -1
    if(allAnnotations.length == 0){
      log(' 0 length')
      latestID = 0

    }
    else{
      latestID = _.max(_.pluck(this.annotations, 'ID')) 

    }

   


    this.annotations.push({
      ID: latestID + 1,
      end: this.newEndPosition,
      start: this.newStartPosition,
      id: 'frag' + (latestID + 1),
      title: cde,
      selectedText: this.getSelectedText(
        this.newStartPosition,
        this.newEndPosition,
      ),
      pageNumber: nearestPage,
    });

    log('afta push ', _.pluck(this.annotations, 'ID'));

    setTimeout(() => {
      try {
        document.querySelector('#fragments').scrollTop = 9999990;
      } catch (error) {}
    }, 2000);
  };

  @observable allCDEs = [
  
  ];

  @action
  set_allCDEs = (data) => {
    this.allCDEs.length = 0;

    _.map(_.keys(data), (item, index) => {
      if (item.includes('cde_')) {
        this.allCDEs.push({
          Id: index,
          checked: data[item] == 'true',
          column: item,
          Name: item.split('cde_')[1].replace('_', ' '),
        });
      }
    });
  };

  @action
  toggleCDE = (id: number, checked: boolean) => {
    let item = _.first(
      _.where(this.allCDEs, {
        Id: id,
      }),
    );

    item.checked = checked;
  };

  @computed get selectedCDEs() {
    return _.where(this.allCDEs, {
      checked: true,
    });
  }

  @observable popOverItems = [
    'Price Escalation',
    'Effective Date',
    'CDE3',
    'CDE4',
  ];

  @observable popOverVisible = false;
  popOverX = 0;
  popOverY = 0;

  @action
  showPopover = () => {
    this.popOverVisible = true;
  };
  @action
  hidePopover = () => {
    this.popOverVisible = false;
  };
  @action
  setPopOverPosition = (x: number, y: number) => {
    (this.popOverX = x), (this.popOverY = y);
  };

  @observable pageFragments: number[] = [];

  pageBeginingIndex: number[] = [];

  @action
  checkHighlight = (index: number) => {
    let flag = false;
    let classTag = '';

    // let pageStartIndex = -1;
    // if(this.activePageNumber >= this.pageBeginingIndex.length){
    //   pageStartIndex = this.fullText.length-1
    // }else{
    //   // log('pagstart')
    //   pageStartIndex = this.pageBeginingIndex[this.activePageNumber];
    // }

    // let pageEndIndex = -1;
    // if(this.activePageNumber >= this.pageBeginingIndex.length-1){
    //   pageEndIndex = this.fullText.length
    // }else{
    //   // log('pageEND')
    //   pageEndIndex = this.pageBeginingIndex[this.activePageNumber + 1];
    // }

    // //  log('pageStartIndex',pageStartIndex)
    // //  log('pageEndIndex',pageEndIndex)

    // if (index < pageStartIndex +1 || index > pageEndIndex-1) {
    //   return 'notOnCurrentPage';
    // }

    this.annotations.map((currAnnotation) => {
      if (currAnnotation.start == index) {
        // log(index, "-", letter, "-", "start "+fragment.id)
        let nearestPage = -1;
        this.pageBeginingIndex.map((pageBeginingIndex, ind) => {
          if (index < pageBeginingIndex) {
            nearestPage = ind;
          }
        });
        classTag =
          ' tokenStart bg-red-200 ' +
          ' lastPageBegining' +
          nearestPage +
          ' ' +
          currAnnotation.id;
      } else if (index > currAnnotation.start && index <= currAnnotation.end) {
        //log(index, "-", letter, "-", "middle "+fragment.id)
        classTag = ' bg-blue-200 ' + currAnnotation.id;
      }
    });

    let currentWord = this.textSplit[index];
    let isOnPage = -1;

    if (currentWord.includes('-->{')) {
      isOnPage = parseInt(currentWord.split('-->{')[1].split('}<--')[0]);
      if (this.pageFragments.includes(isOnPage)) {
        var t = 0;
      } else {
        this.pageFragments.push(isOnPage);
      }
    }

    return (
      classTag + (isOnPage == -1 ? '' : ' ' + 'pageStart pageNumber' + isOnPage)
    );
  };
}

export default new AppStore();
