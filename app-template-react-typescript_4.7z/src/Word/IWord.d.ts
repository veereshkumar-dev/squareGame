import * as React from 'react';
declare module 'react-read-pdf'

export interface WordProps {
  className?: string;
  children?: React.ReactNode;
  index:number,
  checkHighlight:text, 
  isPageStart:boolean, 
  pageNumber:number, 
  text:string,

}

export function Word(props: WordProps): React.ReactNode;
