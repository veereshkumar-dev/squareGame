import * as React from 'react';
declare module 'react-read-pdf'

export interface LoadingProps {
  className?: string;
  children?: React.ReactNode;
}

export function Loading(props: LoadingProps): React.ReactNode;
