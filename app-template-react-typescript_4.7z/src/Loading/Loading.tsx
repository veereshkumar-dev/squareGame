import React, { Component } from 'react';
import './Loading.scss';

import $ from 'jquery';

import {
  action,
  computed,
  makeAutoObservable,
  makeObservable,
  observable,
} from 'mobx';
import { observer } from 'mobx-react';


import Lib from '../Lib';
const { log, AppStore, _ } = Lib;

class Store {
  constructor() {
    makeAutoObservable(this);
  }

  @observable show = false;
  @observable text = 'loadin';
  @observable pageNumber = 1;

  @action
  changePagen() {
    //    this.pageNumber = 2;
  }
  @action
  showComponent() {
    log(9999);
    this.show = true;
  }
}

@observer
export default class Loading extends Component {
  store = new Store();

  

  componentDidMount() {
    setTimeout(() => {
      this.store.showComponent()
    }, 1000);
    
    setTimeout(() => {
      log(99)
      AppStore.set_UserName('VeereshKumar')
    }, 2000);

  }

  public render() {
    return (
      <div
        className={
          (this.store.show ? ' uk-animation-slide-bottom-small ' : ' uk-invisible ') +
          'loading uk-width-3-4  flex flex-col  h-screen'
        }
      >
        
        <div className="loading uk-flex w-screen h-screen">Loading {AppStore.userName}</div>

      </div>
    );
  }
}
