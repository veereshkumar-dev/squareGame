import React, { Component } from 'react';
import './PopOver.scss';

import { observer } from 'mobx-react';

//import './PopOver.scss';

import Lib from '../Lib';
const { log, AppStore } = Lib;

@observer
export default class PopOver extends Component {
  componentDidMount() {}

  public render() {
    log('renderin');
    const style = {
      position: 'absolute',
      left: AppStore.popOverX,
      top: AppStore.popOverY,
    };
    return (
      <div
        onMouseLeave={() => {
          AppStore.hidePopover();
        }}
        style={style}
        className={
          (AppStore.popOverVisible ? ' ' : ' uk-invisible ') +
          'popOver uk-box-shadow-large flex flex-col '
        }
      >
        {AppStore.popOverVisible ? (
          <ul
            // uk-scrollspy="cls: uk-animation-slide-bottom-small; target: .cde; delay:40; "
            className="uk-list bg-white ukshadow  uk-list-striped border-2 uk-animation-slide-bottom-small cursor-pointer"
          >
            {AppStore.selectedCDEs.map((item) => {
              return (
                <li
                  key={item.Id}
                  className="cde hover:bg-gray-200 "
                  onClick={() => {
                    AppStore.hidePopover();
                    AppStore.addAnnotation(item.Name);
                  }}
                >
                  {item.Name}
                </li>
              );
            })}
          </ul>
        ) : (
          ''
        )}
      </div>
    );
  }
}
