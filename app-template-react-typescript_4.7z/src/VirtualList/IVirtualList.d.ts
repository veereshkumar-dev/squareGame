import * as React from 'react';
declare module 'react-read-pdf'

export interface VirtualListProps {
  className?: string;
  children?: React.ReactNode;
}

export function VirtualList(props: VirtualListProps): React.ReactNode;
