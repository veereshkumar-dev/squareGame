import React, { Component } from 'react';
import './VirtualList.scss';

import {
  action,
  computed,
  makeAutoObservable,
  makeObservable,
  observable,
} from 'mobx';
import { observer } from 'mobx-react';

//import './VirtualList.scss';

import Lib from '../Lib';
const { log, AppStore } = Lib;

import { useRef } from 'react';
import ViewportList from 'react-viewport-list';

const VirtualList = ({ items }) => {
  const ref = useRef(null);
  const listRef = useRef(null);

  return (
    <div className="scroll-container" ref={ref}>
       <button className="up-button" onClick={() => listRef.current.scrollToIndex(200)} >
        lksjdlfk skdfdslk
       </button>

      <ViewportList
        ref={listRef}
        viewportRef={ref}
        items={items}
        itemMinSize={40}
      >
        {(text, index) => {
          let checkHighlight = AppStore.checkHighlight(index);
          let isPageStart = checkHighlight.includes('pageStart');
          let pageNumber = isPageStart
            ? checkHighlight.split('pageNumber')[1]
            : 0;

          return (
            <span
              key={index}
              onMouseDown={() => {
                log('start');
                AppStore.recordStart(index);
              }}
              onMouseUp={(e) => {
                log('end');
                //$('.popover').css({ top: e.pageY - 80, left: e.pageX });

                AppStore.recordEnd(index);
                AppStore.showPopover();
              }}
              {...(checkHighlight.includes('tokenStart') ||
              checkHighlight.includes('pageStart')
                ? {
                    id: isPageStart
                      ? 'pageStart' + pageNumber.toString()
                      : checkHighlight.includes('tokenStart')
                      ? 'frag' + checkHighlight.split('frag')[1]
                      : '',
                  }
                : {})}
              className={checkHighlight}
            >
              {text + ' '}
            </span>
          );
        }}
      </ViewportList>
    </div>
  );
};

export default VirtualList;
