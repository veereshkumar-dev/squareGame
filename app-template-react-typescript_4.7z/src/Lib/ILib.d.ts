import * as React from 'react';
declare module 'react-read-pdf'

export interface LibProps {
  className?: string;
  children?: React.ReactNode;
}

export function Lib(props: LibProps): React.ReactNode;
