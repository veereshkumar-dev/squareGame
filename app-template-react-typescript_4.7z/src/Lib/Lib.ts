
import AppStore from '../Store/AppStore';


import _log from "ololog";
import { observer } from 'mobx-react';
let log = _log.configure({
  locate: false,
  time: false,
  stringify: {
    pure: false,
    json: true,
    maxDepth: 5,
    maxLength: 50,
    maxArrayLength: 60,
    maxObjectLength: 200,
    maxStringLength: 60,
    precision: 2,
    formatter: undefined,
    pretty: "auto",
    rightAlignKeys: true,
    fancy: true,
    indentation: " ",
  },
});

import moment from 'moment'
import * as _ from 'underscore'

export default{
  log, AppStore, observer, moment, _
}
