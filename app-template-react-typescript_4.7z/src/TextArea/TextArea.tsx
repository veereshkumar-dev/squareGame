import React, { Component } from 'react';
// import './TextArea.scss';
import { TextAreaProps } from './ITextArea';

import PDF from 'react-read-pdf';
const { PDFReader } = PDF;

import { Document, Page } from 'react-pdf';
import { pdfjs } from 'react-pdf';
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

import {
  action,
  computed,
  makeAutoObservable,
  makeObservable,
  observable,
} from 'mobx';
import { observer } from 'mobx-react';

// import '../../../node_modules/tailwindcss/dist/tailwind.css'

import './TextArea.scss';

import Lib from '../Lib';
const { log, AppStore } = Lib;

class Store {
  constructor() {
    makeAutoObservable(this);
  }

  @observable show = false;
  @observable text = 'loadin';
  @observable pageNumber = 1;

  @action
  changePagen() {
    this.pageNumber = 2;
  }
  @action
  showComponent() {
    log(9999);
    this.show = true;

    setTimeout(() => {
      AppStore.nextPage();
    }, 2000);
  }
}

@observer
export default class TextArea extends Component<TextAreaProps> {
  store = new Store();

  componentDidMount() {
    setTimeout(() => {
      this.store.showComponent();
      AppStore.nextPage();
    }, 5001);
    // Asynchronous download of PDF
  }

  public render() {
    return (
      <div className="textSection flex flex-col uk-animation-slide-bottom-small  w-1/2 bg-red-300">
        kkk
        <Document
        // renderMode="svg"
          file="http://localhost:8090/test.pdf"
          onLoadSuccess={() => {}}
          beginAnnotations={()=>{}}
        >
          <Page pageNumber={AppStore.pageNumber} />
        </Document>
        jjk
      </div>
    );
  }
}
