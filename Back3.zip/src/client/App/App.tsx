import React from "react";
import { AppStyled } from "./styles";

const App = () => {
  return <AppStyled>Welcome to the React Final 5 Boiler Plate</AppStyled>;
};

export default App;
