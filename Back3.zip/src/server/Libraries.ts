
import _log from "ololog";
let log = _log.configure({
  locate: false,

  time: false,
  stringify: {
    pure: false,
    json: true,
    maxDepth: 5,
    maxLength: 50,
    maxArrayLength: 60,
    maxObjectLength: 200,
    maxStringLength: 60,
    precision: 2,
    formatter: undefined,
    pretty: "auto",
    rightAlignKeys: true,
    fancy: true,
    indentation: " ",
  },
});

import * as _ from 'underscore'
const moment = require("moment");
import * as lodash from 'lodash'
let toNumber = lodash.toNumber

export {
    log,
    _,
    lodash,
    moment,
    toNumber,
}