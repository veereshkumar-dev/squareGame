import * as _knex from 'knex';
import NP from 'number-precision'
import log from 'ololog'
import * as _ from 'underscore'


import * as moment from 'moment'
import * as Sqlite from 'better-sqlite3';

//let db: any = Sqlite('src/server/DataBase/ltpDB.db');
let db: any = Sqlite('../../src/server/DataBase/ltpDB.db');



NP.enableBoundaryChecking(false)

//#region DB Related code
//Query rows
let query = (sql: string) => {
    try {
        let res = db.prepare(sql)
            .all()
        return res
    } catch (err) {
        if (err.toString()
            .includes('UNIQUE constraint failed:')) {
            //log('UNIQUE constraint')
            return null
        }
        
        log.red(err.toString()
            .substr(0, 120))

        return null
    }
}

//Modify DB
let run = (sql: string) => {
    try {
        let res = db.prepare(sql)
            .run()
        return res
    } catch (err) {
        if (err.toString()
            .includes('UNIQUE constraint failed:')) {
            //log('UNIQUE constraint')
            return null
        }

        // log('----Error-----')
        // log('Error executing query ')
        log.red(err.toString()
            .substr(0, 120))
        // log('----End-----')

        return err.toString()
            .substr(0, 120)
    }
}

//knex standin for autocomplete

let knex:_knex.Knex = _knex.knex ({
    client: 'sqlite3',
    connection: ':memory:',
    useNullAsDefault: true
});


//#endregion


class GenericHelpers {
    getSumOfArray = (arr: number[]) => {
        // returns the sum total of all values in the array
        return _.reduce(arr, function (memo: number, num: number) { return memo + num }, 0);
    }
    getAverageOfArray = (arr: number[]) => {
        // returns the average of all values in the array
        return this.getSumOfArray(arr) / arr.length;
    }

    round = (num: number): number => {
        return NP.round(num, 2)
    }

    round0 = (num: number): number => {
        return NP.round(num, 0)
    }

    round1 = (num: number): number => {
        return NP.round(num, 1)
    }

    round2 = (num: number): number => {
        return NP.round(num, 1)
    }

    percentDifference = (a: number, b: number) => {
        return 100 * Math.abs((a - b) / ((a + b) / 2));
    }

    getPercentageDifferenceWRT = (a: number[], b: number) => {
        return _.map(a, ((item: any) => {
            return this.percentDifference(item, b)
        }))
    }


    getTimeDifference_minutes = (startTime: moment.Moment, endTime: moment.Moment) => {
        var duration = moment.duration(endTime.diff(startTime));
        var minutes = duration.asMinutes() % 60;

        return minutes
    }

    getTimeDifference_hours = (startTime: moment.Moment, endTime: moment.Moment) => {
        

        let durationNumber = endTime.diff(startTime)

        let duration = moment.duration(durationNumber);
        
        var hours = duration.asHours() % 60;

        return hours
    }
}

let genericHelpers = new GenericHelpers()



interface Iint {
    getName(): string
}

class Greeter implements Iint {
    greeting: string;

    constructor(message: string) {
        this.greeting = message;
    }

    greet() {
        return "Hello, " + this.greeting;
    }

    getName() {
        return 'Hello Greeter'
    }
}

let greeter = new Greeter("world");

log(greeter.getName())

// module.exports = {
//     knex:knex
// }

export {
    knex,
    query,
    run,
    genericHelpers,
}