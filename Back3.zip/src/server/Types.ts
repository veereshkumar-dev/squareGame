export enum Direction {
  Buy,
  Sell,
}

export enum StockType {
  EQUITY,
  FnO,
  COM
}

export type ISignal ={
  Strategy:string,
  Message:string,
  Direction:Direction,
  Symbol: string,
  Quantity:number
}


export type IPayload_PlaceOrder = {
  symbolID:string, 
  direction:Direction,
  instrument:StockType,
  message:string
}


export enum Status {
  Open,
  Executed,
  Cancled,
}

// export type IOrder = {
//     Id: number,
//     Direction: Direction,
//     Price: number,
//     Time: number,
//     Status: Status
// }

export type IBrokerCandle = {
  time?: number;
  open?: number;
  high?: number;
  low?: number;
  close?: number;
};

export type ITraderCandle = {
  time?: number;
  open?: number;
  high?: number;
  low?: number;
  close?: number;
  TChannel_Toggle_T15?: number;
  TChannel_Upper_T15?: number;
  TChannel_Middle_T15?: number;
  TChannel_Lower_T15?: number;
  TChannel_Toggle_T60?: number;
  TChannel_Upper_T60?: number;
  TChannel_Middle_T60?: number;
  TChannel_Lower_T60?: number;
  TChannel_Toggle_T120?: number;
  TChannel_Upper_T120?: number;
  TChannel_Middle_T120?: number;
  TChannel_Lower_T120?: number;
  VWMACD_T120?: number;
  VWMACD_T60?: number;
  VWMACD_T15?: number;
  Angle_1_T120?: number;
  Angle_2_T120?: number;
  Angle_3_T120?: number;
  Angle_4_T120?: number;
  Angle_5_T120?: number;
  Angle_6_T120?: number;
  Angle_1_T60?: number;
  Angle_2_T60?: number;
  Angle_3_T60?: number;
  Angle_4_T60?: number;
  Angle_5_T60?: number;
  Angle_6_T60?: number;
  Angle_1_T15?: number;
  Angle_2_T15?: number;
  Angle_3_T15?: number;
  Angle_4_T15?: number;
  Angle_5_T15?: number;
  Angle_6_T15?: number;
};

export type IPosition = {
  Id: string;
  Instrument: string;
  Symbol: string;
  SymbolId: string;
  Exchange: string;
  Product: string;

  LTP: number;
  MTM: number;
  Realised_Profit: number;

  Buy_Avg: number;
  Sell_Avg: number;

  Net_Qty: number;
  Net_Val: number;
  Net_Avg: number;

  Total_Buy_Qty: number;
  Total_Buy_Val: number;
  Total_Sell_Qty: number;
  Total_Sell_Val: number;

  Expiry: string;
  Strike: string;
};

export type IOrder = {
  Id: string;
  Time: string;

  Order_Number: number;
  Exchange: string;
  Direction: string;
  Instrument: string;
  Symbol: string;
  Product: string;
  Status: string;
  Quantity: number;
  Remaining_Quantity: number;
  Price: number;
  Traded_Price: number;
  Trigger_Price: number;
  Order_Type: string;
  Reason: string;

  Expiry: string;
  Strike: string;
};

export type IPayLoad = {
  invokedBy: string;
  data?: any;
};

export type ILTP = {
  Symbol:string,
  LTP?:number,
  ShoonyaID?:string
}

export type IPayload_LTP = {
  invokedBy: string;
  data: ILTP[];
  
}
