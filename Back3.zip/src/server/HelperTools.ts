import { log, _, lodash } from "./Libraries";
import {
  IOrder,
  IPosition,
  IPayLoad,
  Direction,
  StockType,
  ILTP,
} from "./Types";
import * as db from "./DataBase/sqlBackendBD";
import * as ltp_db from "./DataBase/sqlLTPBD";
import { isNull } from "underscore";


export const getClosestIndex = (num:number, arr:any) => {
  let curr = arr[0],
    diff = Math.abs(num - curr);
  let index = 0;
  for (let val = 0; val < arr.length; val++) {
    let newdiff = Math.abs(num - arr[val]);
    if (newdiff < diff) {
      diff = newdiff;
      curr = arr[val];
      index = val;
    }
  }
  return index;
};

export function getStandard_Orders(orders: any[]) {
  let standardOrders: IOrder[] = [];
  

  _.map(orders, (item) => {

    let rightSymbol = '';
    try {
      let ltp = read_ltpDB("LTP");


      rightSymbol = _.first(
        _.where(ltp, {
          ShoonyaID:String(item.SEM_SECURITY_ID),
        })
      ).Symbol;

    } catch (error) {}

    standardOrders.push({
      Id: item.ORDER_NUMBER,
      Time: item.ORDER_DATE_TIME,

      Order_Number: item.ORDER_NUMBER,
      Exchange: item.EXCHANGE,
      Direction: item.BUY_SELL,
      Instrument: item.INSTRUMENT,
      Symbol: rightSymbol?rightSymbol:item.SYMBOL,
      Product: item.PRODUCT,
      Status: item.STATUS,
      Quantity: item.QUANTITY,
      Remaining_Quantity: item.REMAINING_QUANTITY,
      Price: item.PRICE,
      Traded_Price: item.TRADED_PRICE,
      Trigger_Price: item.TRG_PRICE,
      Order_Type: item.ORDER_TYPE,
      Reason: item.REASON_DESCRIPTION,

      Expiry: item.EXPIRY_DATE,
      Strike: item.STRIKE_PRICE,
    });
  });

  return standardOrders;
}

export function getStandard_Positions(positions: any[]) {
  let standardPositions: IPosition[] = [];

  _.map(positions, (item) => {
    standardPositions.push({
      Id: item.SECURITY_ID,
      Instrument: item.INSTRUMENT,
      Symbol: item.SYMB_SECID,
      SymbolId: item.SECURITY_ID,
      Exchange: item.EXCH_ID,
      Product: item.PROD_ID,

      LTP: item.LAST_TRADED_PRICE,
      MTM: item.MTM,
      Realised_Profit: item.REALISED_PROFIT,

      Buy_Avg: item.BUY_AVG,
      Sell_Avg: item.SELL_AVG,

      Net_Qty: item.NET_QTY,
      Net_Val: item.NET_VAL,
      Net_Avg: item.NET_AVG,

      Total_Buy_Qty: item.TOT_BUY_QTY,
      Total_Buy_Val: item.TOT_BUY_VAL,
      Total_Sell_Qty: item.TOT_SELL_QTY,
      Total_Sell_Val: item.TOT_SELL_VAL,

      Expiry: item.EXPIRY_DATE,
      Strike: item.STRIKE_PRICE,
    });
  });
  return standardPositions;
}


export function writeToDB_Orders(orders: IOrder[]) {
  let sql, result;

  _.map(orders, (currentOrder) => {
    sql = db.knex("Orders").insert(currentOrder).toString();

    result = db.run(sql);
  });

  log("Stored Orders in DB!");
}

export function writeToDB_Positions(orders: IPosition[]) {
  let sql, result;

  _.map(orders, (currentOrder) => {
    if (currentOrder && currentOrder.Symbol) {
      sql = db
        .knex("Positions")
        .insert(currentOrder)
        .onConflict("Id")
        .merge()
        .toString();

      result = db.run(sql);
    } else {
      let jj = 0;
    }
  });

  //log("Stored Positions in DB!");
}

export function writeToDB_LTP(ltps: ILTP[]) {
  let sql, result;

  _.map(ltps, (currentLTP) => {
    sql = ltp_db
      .knex("LTP")
      .insert(currentLTP)
      .onConflict("Symbol")
      .merge()
      .toString();
    result = ltp_db.run(sql);
  });

  //log("Updated LTPs in DB!");
}

export function read_ltpDB(tableName: string) {
  let sql, result;

  sql = db.knex(tableName).select().toString();
  result = ltp_db.query(sql);
  return result;
}

export function readDB(tableName: string) {
  let sql, result;

  sql = db.knex(tableName).select().toString();
  result = db.query(sql);
  return result;
}

export function getOptionID(nearLTP: number, message: string) {
  let LTPs = read_ltpDB("LTP");
  let Options = [];

  if (message.toLowerCase().includes("call")) {
    Options = _.filter(LTPs, (item) => {
      return item.Symbol.includes("CE");
    });
  } else if (message.toLowerCase().includes("put")) {
    Options = _.filter(LTPs, (item) => {
      return item.Symbol.includes("PE");
    });
  }

  let Options_LTPs = _.pluck(Options, "LTP");
  let closestToNearLTP_index = getClosestIndex(nearLTP, Options_LTPs);

  return Options[closestToNearLTP_index].ShoonyaID;
}

export function getPayload_PlaceOrder(
  symbolID: string,
  direction: Direction,
  instrument: StockType
) {
  if (instrument == StockType.EQUITY) {
    return {};
  } else if (instrument == StockType.COM) {
    return {};
  } else if ((instrument = StockType.FnO)) {
    return {
      qty: 25,
      price: "MKT",
      odr_type: "MKT",
      product_typ: "I",
      trg_prc: 0,
      validity: "DAY",
      disc_qty: 0,
      amo: false,
      sec_id: symbolID,
      inst_type: "OPTIDX",
      exch: "NSE",
      buysell: direction == Direction.Buy ? "B" : "S",
      gtdDate: "0000-00-00",
      mktProtectionFlag: "N",
      mktProtectionVal: 0,
      settler: "000000000000",
      token_id: "a8ba6ffb3b2d672ef213",
      keyid: "yUAmvv6QBvUA0ZpfuFnI3jU9xL6dDTJm552vaceTTGE=",
      userid: "FA24064",
      clienttype: "C",
      usercode: "10499",
      pan_no: "AJHPH1469G",
    };
  }
}

export function getLivePositions() {
  let orders = readDB("Orders");

  orders = _.filter(orders,(order=>{
    return order.Status == "Traded"
  }))

  let ltp = read_ltpDB("LTP");

  let uniqueSymbols = _.uniq(_.pluck(orders, "Symbol"));

  let positions:any[] = [];
  _.map(uniqueSymbols, (item) => {
    //Symbol
    //log(item)

    let LTP_obj = _.first(
      _.where(ltp, {
        Symbol: item,
      })
    );

    //Position Quantity
    let itemOrders = _.filter(orders, (order) => {
      return order.Symbol == item;
    });
    let buyQuantity = _.where(itemOrders, {
      Direction: "Buy",
    });

    let sellQuantity = _.where(itemOrders, {
      Direction: "Sell",
    });

    let buyCount = _.pluck(buyQuantity, "Quantity").reduce((a, b) => a + b, 0);
    let sellCount = _.pluck(sellQuantity, "Quantity").reduce(
      (a, b) => a + b,
      0
    );

    let totalQuantity: number = buyCount - sellCount;

    //Last Order Time
    let latestOrder = _.first(_.sortBy(itemOrders, "Time").reverse());
    let restOfOrders = _.without(itemOrders, latestOrder);

    // log("latestOrder",latestOrder)
    // log("restOfOrders",restOfOrders)

    if (totalQuantity != 0) {
      positions.push({
        Symbol: item,
        Quantity: totalQuantity,
        LastOrderTime: latestOrder.Time,
        EntryPrice: latestOrder.Traded_Price,
        LTP: LTP_obj ? LTP_obj.LTP : "null",
        PnL: LTP_obj
          ? db.genericHelpers.round2(
              (LTP_obj.LTP - latestOrder.Traded_Price) * totalQuantity
            )
          : "null",
      });
    }
  });

  return positions;
}
