import { log, _, lodash, moment } from "./Libraries";

import knex from "knex";

const Database = require("better-sqlite3");
import * as db from "./DataBase/sqlBackendBD";

let config = {
  pauseTrading: true,

  lastOrderTime: null,
  lastRefreshTime: null,
  finalRefresh: false,
};

// Require the framework and instantiate it
const fastify = require("fastify")();

fastify.register(require("fastify-cors"), {
  origin: true,
});

const dirTree = require("directory-tree");
const tree = dirTree(
  "D:\\Coding\\OfficeProjects\\Back3\\src\\server\\Contracts\\"
);

let Contracts = [];
_.map(tree.children, (child) => {
  let contract = {
    contractID: child.name,
    path: child.path,
    pdfURL: child.children[0].name,
    textURL: child.children[1].name,
  };

  Contracts.push(contract);
});

_.map(Contracts, (contract) => {
  let sql,
    result = null;

  sql = db
    .knex("Contracts")
    .insert(contract)
    .onConflict("contractID")
    .merge()
    .toString();

  result = db.run(sql);
  log(result);
});

const path = require("path");
fastify.register(require("fastify-static"), {
  root: path.join(__dirname, "contracts"),
  prefix: "/foo",
  list: true,
  index: false,
});

fastify.get("/getFile/:directory/:fileName", function (request, reply) {
  let filePath = request.params.directory + "/" + request.params.fileName;
  log(filePath);
  reply.sendFile(filePath);
});

let random = 0
fastify.get("/getNextContract", (request, reply) => {
  //let random = Math.round(Math.random());
  random = random==0?1:0
  log('ranom:', random)
  
  let sql,
    result = null;

  sql = db
    .knex("Contracts")
    .select()
    .where({
      contractID: random==1? 11111:22222
    })
    .toString();

  result = db.query(sql);
  log(result);


  reply.send(result);
});

const split2 = require("split2");
const pump = require("pump");

fastify.addContentTypeParser("*", (request, payload, done) => {
  done(null, pump(payload, split2(JSON.parse)));
});

fastify.route({
  method: "POST",
  url: "/api",
  handler: (req, res) => {
    req.body.on("data", (d) => console.log(d)); // log every incoming object
  },
});

fastify.post("/saveContractAnnotations/:contractID", (request, reply) => {
  // log(request.params.contractID);
  // log(request.body);

  let JSONOutput = JSON.stringify(request.body.annotations)
  let CDEs = request.body.cdes

  
  let contractData = {
    contractID: request.params.contractID,
    JSONOutput: JSONOutput,
  };

  let checkedCDEs = _.where(CDEs, {
    checked:true
  } )

  let cdeColumns = _.pluck(checkedCDEs, 'column')
 
  log('cdeColumns',cdeColumns)
  
  _.map(cdeColumns, cdeColumn=>{
    contractData[cdeColumn] = 'true'
  })


  log(contractData)

  let sql,
    result = null;

  sql = db
    .knex("Contracts")
    .insert(contractData)
    .onConflict("contractID")
    .merge()
    .toString();

  result = db.run(sql);
  log(result);

  reply.send({ saved: "true" });
});

fastify.listen(3000, '192.168.1.36', (err) => {
  if (err) {
    fastify.log.error(err);
    process.exit(1);
  }
});
