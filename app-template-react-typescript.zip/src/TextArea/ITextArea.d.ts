import * as React from 'react';
declare module 'react-read-pdf'

export interface TextAreaProps {
  className?: string;
  children?: React.ReactNode;
}

export function TextArea(props: TextAreaProps): React.ReactNode;
