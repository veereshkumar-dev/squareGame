import React, { Component } from 'react';
import './TextSection.scss';
import {
  action,
  computed,
  makeAutoObservable,
  makeObservable,
  observable,
} from 'mobx';
import { observer } from 'mobx-react';

import ViewportList from 'react-viewport-list';

import Lib from '../Lib';
const { log, AppStore, _ } = Lib;

class Store {
  constructor() {
    makeAutoObservable(this);
  }

  @observable show = false;
  @observable oveflowShown = false;

  @action
  showComponent() {
    setTimeout(() => {
      this.show = true;

      setTimeout(() => {
        this.oveflowShown = true;
      }, 800);
    }, 1000);
  }
}

@observer
export default class TextSection extends Component {
  store = new Store();

  componentDidMount() {
    fetch('http://localhost:8090/test.txt')
      .then((response) => response.text())
      .then((response) => {
        //log(response)
        AppStore.setText(response);
        AppStore.pageLoaded = true;
      });

    this.store.showComponent();
  }

  public render() {
    return (
      <div
        className={
          (this.store.show ? '' : ' uk-invisible ') +
          'textSection uk-width-3-6 flex flex-col h-screen  '
        }
      >
        <div
          id={'textContainer'}
          className={
            (this.store.show
              ? ' uk-animation-slide-bottom '
              : ' uk-invisible ') +
            (this.store.oveflowShown
              ? ' overflow-y-scroll  '
              : ' overflow-hidden ') +
            ' spanSection uk-animation  overflow-hidden   p-8 '
          }
        >
          {/* <VirtualList items={AppStore.textSplit}/> */}

          {_.map(AppStore.textSplit, (text: string, index: number) => {
            let checkHighlight = AppStore.checkHighlight(index);
            let isPageStart = checkHighlight.includes('pageStart');
            let pageNumber = isPageStart
              ? checkHighlight.split('pageNumber')[1]
              : 0;
            return (
              <span
                key={index}
                onMouseDown={() => {
                  log('start');
                  AppStore.hidePopover();
                  AppStore.recordStart(index);
                }}
                onMouseUp={(e) => {
                  log('end');
                  //$('.popover').css({ top: e.pageY - 80, left: e.pageX });

                  AppStore.setPopOverPosition(e.pageX, e.pageY);
                  

                  AppStore.recordEnd(index);
                  log(AppStore.newStartPosition, '--', AppStore.newEndPosition);
                  if (AppStore.newStartPosition != AppStore.newEndPosition) {
                    log('---> true')
                    AppStore.showPopover();
                  }
                }}
                {...(checkHighlight.includes('tokenStart') ||
                checkHighlight.includes('pageStart')
                  ? {
                      id: isPageStart
                        ? 'pageStart' + pageNumber.toString()
                        : checkHighlight.includes('tokenStart')
                        ? 'frag' + checkHighlight.split('frag')[1]
                        : '',
                    }
                  : {})}
                className={checkHighlight}
              >
                {text + ' '}
              </span>
            );
          })}
        </div>
      </div>
    );
  }
}
