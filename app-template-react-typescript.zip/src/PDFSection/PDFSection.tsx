import React, { Component } from 'react';
import './PDFSection.scss';
import { PDFSectionProps } from './IPDFSection';

import PDF from 'react-read-pdf';
const { PDFReader } = PDF;

import { Document, Page } from 'react-pdf';
import { pdfjs } from 'react-pdf';
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

import {
  action,
  computed,
  makeAutoObservable,
  makeObservable,
  observable,
} from 'mobx';
import { observer } from 'mobx-react';

//import './PDFSection.scss';

import Lib from '../Lib';
const { log, AppStore } = Lib;

class Store {
  constructor() {
    makeAutoObservable(this);
  }

  @observable show = false;
  @observable text = 'loadin';
  @observable pageNumber = 1;

  @action
  changePagen() {
    //    this.pageNumber = 2;
  }
  @action
  showComponent() {
    log(9999);
    this.show = true;

    setTimeout(() => {}, 2000);
  }
}

@observer
export default class PDFSection extends Component<PDFSectionProps> {
  store = new Store();

  componentDidMount() {
    // setTimeout(() => {
    //   this.store.showComponent();
    // }, 5001);
    // Asynchronous download of PDF
  }

  public render() {
    return (
      <div
        className={
          (this.store.show ? ' uk-animation-slide-bottom ' : ' uk-invisible ') +
          'pdfSection uk-width-3-4  flex flex-col  h-screen'
        }
      >
        <Document
          renderMode="svg"
          file="http://localhost:8090/test.pdf"
          onLoadSuccess={() => {
            log('loaded');

            setTimeout(() => {
              this.store.showComponent();
            }, 200);
          }}
          beginAnnotations={() => {}}
        >
          <Page pageNumber={AppStore.pageNumber==0?1:AppStore.pageNumber} />
        </Document>
      </div>
    );
  }
}
