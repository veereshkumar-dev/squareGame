export { default } from "./SidePannel";
