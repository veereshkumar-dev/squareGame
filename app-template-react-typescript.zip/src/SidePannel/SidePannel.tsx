import React, { Component } from 'react';

import {
  action,
  computed,
  makeAutoObservable,
  makeObservable,
  observable,
} from 'mobx';
import { observer } from 'mobx-react';
import LinesEllipsis from 'react-lines-ellipsis';

import './SidePannel.scss';

import Lib from '../Lib';
const { log, AppStore } = Lib;

class Store {
  constructor() {
    makeAutoObservable(this);
  }

  @observable show = false;
  @observable text = 'loadin';
  @observable pageNumber = 1;

  @action
  changePagen() {
    this.pageNumber = 4;
  }
  @action
  showComponent() {
    log(9999);
    this.show = true;

    setTimeout(() => {
      AppStore.nextPage();
    }, 2000);
  }
}

@observer
export default class SidePannel extends Component {
  store = new Store();

  componentDidMount() {
    // Asynchronous download of PDF
  }

  public render() {
    return (
      <div className="sidePannel uk-width-1-2 flex flex-col uk-animation-slide-bottom-small h-screen  ">
        <div className="metadata  flex uk-flex-center uk-align-center ">
          {/* <div className="flex">Page: {AppStore.pageNumber}</div> */}
          <div className="flex flex-col justify-between">
            <button
              className="uk-button uk-button-primary"
              onClick={() => {
                try {
                  let pageID = 'pageStart' + (AppStore.pageNumber+1).toString();
                  log(pageID);
                  let elmnt = document.getElementById(pageID);
                  elmnt.scrollIntoView();
                } catch (error) {
                } finally {
                  setTimeout(() => {
                    AppStore.nextPage();
                    
                  }, 700);
                }
              }}
            >
              NExt
            </button>

            <button
              className="uk-button uk-button-primary"
              onClick={() => {
                let pageID = 'pageStart' + (AppStore.pageNumber-1).toString();
                log(pageID);

                if (AppStore.pageNumber == 1) {
                  document.querySelector('#textContainer').scrollTop = 0;
                } else {
                  try {
                    let elmnt = document.getElementById(pageID);
                    elmnt.scrollIntoView();
                  } catch (error) {
                  } finally {
                    setTimeout(() => {
                      AppStore.previousPage();

                      
                    }, 700);
                  }
                }
              }}
            >
              Previous
            </button>

            <button
              className="uk-button uk-button-danger"
              onClick={() => {
                log('exported');
              }}
            >
              Export
            </button>
          </div>

          <div className="flex flex-grow">
            <table className="uk-table uk-table-small bg-white m-0 uk-table-striped border-2">
              <tbody>
                <tr>
                  <td>ID</td>
                  <td>L028387HW</td>
                </tr>
                <tr>
                  <td>SBG</td>
                  <td>AERO</td>
                </tr>
                <tr>
                  <td>Contract Party 1</td>
                  <td>Boeing</td>
                </tr>
                <tr>
                  <td>Contract Party 2</td>
                  <td>Honeywell</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="uk-flex  m-6">
          {AppStore.pageLoaded ? (
            <ul
              id="fragments"
              className="uk-list uk-list-striped overflow-y-scroll"
              uk-scrollspy="cls: uk-animation-slide-bottom; target: .fragment; delay: 150; "
            >
              {AppStore.fragments.map((fragment) => {
                let selectedText = AppStore.getSelectedText(
                  fragment.start,
                  fragment.end,
                );
                //log(selectedText);
                return (
                  <li
                    key={fragment.id}
                    className={
                      selectedText[0] == 'u'
                        ? ' uk-invisible '
                        : 'fragment  hover:bg-gray-200  p-4 cursor-pointer'
                    }
                    onClick={() => {
                      // log(fragment.id.toString());
                      let elmnt = document.getElementById(
                        fragment.id.toString(),
                      );
                      elmnt.scrollIntoView();
                    }}
                  >
                    <div className="title">{fragment.title}</div>
                    <div className="selectedText  ">
                      <LinesEllipsis
                        text={selectedText}
                        maxLine="2"
                        ellipsis="..."
                        trimRight
                        basedOn="words"
                      />
                    </div>
                  </li>
                );
              })}
            </ul>
          ) : (
            ''
          )}
        </div>
      </div>
    );
  }
}
