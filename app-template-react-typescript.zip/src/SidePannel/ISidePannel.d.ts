import * as React from 'react';
declare module 'react-read-pdf'

export interface SidePannelProps {
  className?: string;
  children?: React.ReactNode;
}

export function SidePannel(props: SidePannelProps): React.ReactNode;
