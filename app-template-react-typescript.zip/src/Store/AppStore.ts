import {
  observable,
  computed,
  action,
  makeAutoObservable,
  get,
  toJS,
} from 'mobx';
import Source from './BotStore.json';
import * as _ from 'underscore';
import _log from 'ololog';
let log = _log.configure({
  locate: false,
  time: false,
  stringify: {
    pure: false,
    json: true,
    maxDepth: 5,
    maxLength: 50,
    maxArrayLength: 60,
    maxObjectLength: 200,
    maxStringLength: 60,
    precision: 2,
    formatter: undefined,
    pretty: 'auto',
    rightAlignKeys: true,
    fancy: true,
    indentation: ' ',
  },
});

class AppStore {
  constructor() {
    makeAutoObservable(this);
  }

  @observable exampleText: string = 'one two two';
  @observable pageNumber: number = 0;
  @observable pageText_List: any[] = [];

  @observable firstLinesOfPages: string[] = [];

  @action
  pushFirstLinesOfPages = (line: string) => {
    this.firstLinesOfPages.push(line);
  };

  @action
  nextPage = () => {
    log(this.pageNumber);
    log(this.pageFragments.length);

    if (this.pageNumber > this.pageFragments.length - 1) {
      return;
    }
    log('next');
    this.pageNumber = this.pageNumber + 1;

    //log(this.firstLinesOfPages[this.pageNumber - 1]);
  };

  @action
  previousPage = () => {
    if (this.pageNumber < 1) {
      return;
    }
    log('prev');
    this.pageNumber = this.pageNumber - 1;

    //log(this.firstLinesOfPages[this.pageNumber - 1]);
  };

  @observable text = ``;
  @observable textSplit: string[] = [];

  @action
  setText = (data: string) => {
    this.text = data;
    this.textSplit = data.split(' ');
  };

  @action
  addPageText(newTxt: string, _pageNumber: number) {
    //log(newTxt)
    this.pageText_List.push({
      pageNumber: _pageNumber,
      pageText: newTxt.toLowerCase(),
    });
    log(_pageNumber);
  }

  @computed get allPages() {
    return this.pageText_List;
  }

  @observable newStartPosition: number = -1;
  @observable newEndPosition: number = -1;

  @observable fragments = [
    {
      title: 'Price Escalation',
      start: 25,
      end: 45,
      id: 'frag0',
    },
    {
      title: 'Effective Date',
      start: 12,
      end: 16,
      id: 'frag1',
      selectedText: 'Highlight 2',
    },
    {
      title: 'Price Escalation',
      start: 427,
      end: 444,
      id: 'frag2',
    },

    {
      title: 'Price Escalation',
      start: 927,
      end: 954,
      id: 'frag3',
    },

    {
      title: 'Price Escalation',
      start: 967,
      end: 994,
      id: 'frag4',
    },

  ];
  @computed get reverseFragments(){
    return toJS(this.fragments).reverse()
  }

  @observable pageLoaded = false

  cache_getSelectedText = {};
  getSelectedText = (start: number, end: number) => {
    let id = start + '-' + end;
    if (this.cache_getSelectedText[id]) {
      return this.cache_getSelectedText[id];
    } else {
      let selectedText = '';
      // log('GetSeclected TEXT ', start, '-', end);
      for (let i = start; i <= end; i++) {
        selectedText += this.textSplit[i] + ' ';
      }

      this.cache_getSelectedText[id] = selectedText;
      return selectedText;
    }
  };

  @action
  addSelectedFragments = (cde:string) => {
    log(cde)
    this.fragments.push({
      end: this.newEndPosition,
      start: this.newStartPosition,
      id: 'frag' + this.fragmentID.toString(),
      title: cde,
      selectedText: this.getSelectedText(this.recordStart, this.recordEnd),
    });

    this.fragmentID = this.fragmentID + 1;

    // setTimeout(() => {
    //   document.querySelector('#fragments').scrollTop = 9999990;
    // }, 1000);

    setTimeout(() => {
      document.querySelector('#fragments').scrollTop = 9999990;
    }, 2000);

  };


  @observable popOverItems = [
    "Price Escalation", "Effective Date", "CDE3", "CDE4"
  ]
  @observable popOverVisible = false;
  @action
  showPopover = ()=>{
    this.popOverVisible = true
  }
  @action
  hidePopover = ()=>{
    this.popOverVisible = false
  }
  @action
  setPopOverPosition = (x:number,y:number)=>{
    this.popOverX = x,
    this.popOverY = y
  }

  popOverX = 0
  popOverY = 0

  @observable fragmentID = 5;

  @action
  recordStart = (startIndex: number) => {
    this.newStartPosition = startIndex;
  };

  @action
  recordEnd = (endIndex: number) => {
    this.newEndPosition = endIndex;
  };

//  @observable popupHidden = true;

  // @action
  // showPopup = () => {
  //   this.popupHidden = false;
  // };

  // @action
  // hidePopup = () => {
  //   this.popupHidden = true;
  // };

  @observable pageFragments: number[] = [];

  @action
  checkHighlight = (index: number) => {
    let flag = false;
    let classTag = '';

    this.fragments.map((fragment) => {
      if (fragment.start == index) {
        // log(index, "-", letter, "-", "start "+fragment.id)
        classTag = ' tokenStart bg-red-200 ' + fragment.id;
      } else if (index > fragment.start && index <= fragment.end) {
        //log(index, "-", letter, "-", "middle "+fragment.id)
        classTag = ' bg-blue-200 ' + fragment.id;
      }
    });

    let selectedText = this.textSplit[index];
    let pageBegining = -1;

    if (selectedText.includes('-->{')) {
      pageBegining = parseInt(selectedText.split('-->{')[1].split('}<--')[0]);
      if (this.pageFragments.includes(pageBegining)) {
        var t = 0;
      } else {
        this.pageFragments.push(pageBegining);
      }
    }

    return (
      classTag +
      (pageBegining == -1 ? '' : ' ' + 'pageStart pageNumber' + pageBegining)
    );
  };
}

export default new AppStore();
