import React, { PureComponent } from 'react';
import './SelectCDE.scss';

import { SelectCDEProps } from './ISelectCDE';

import { observer } from 'mobx-react';

import Lib from '../Lib';
const { log, AppStore } = Lib;

const options = [
  { value: 'chocolate', label: 'Chocolate' },
  { value: 'strawberry', label: 'Strawberry' },
  { value: 'vanilla', label: 'Vanilla' },
];

@observer
export default class SelectCDE extends PureComponent {
  public render() {
    // let {index, checkHighlight, isPageStart, pageNumber, text} = this.props

    return (
      <ul className="selectcde uk-list">
        {AppStore.allCDEs.map((currCDE, index) => {
          return (
            <li>
              <label>
                <input
                onChange={()=>{
                  AppStore.toggleCDE(currCDE.Id, !currCDE.checked)
                }}
                className="uk-checkbox" type="checkbox" checked={currCDE.checked} />{' '}
                {currCDE.Name.toString()}
              </label>
            </li>
          );
        })}
      </ul>
    );
  }
}
