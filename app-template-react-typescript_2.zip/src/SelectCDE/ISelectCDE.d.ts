import * as React from 'react';
declare module 'react-read-pdf'

export interface SelectCDEProps {
  className?: string;
  children?: React.ReactNode;
  index:number,
  checkHighlight:text, 
  isPageStart:boolean, 
  pageNumber:number, 
  text:string,

}

export function SelectCDE(props: SelectCDEProps): React.ReactNode;
