import * as React from 'react';
declare module 'react-read-pdf'

export interface TextSectionProps {
  className?: string;
  children?: React.ReactNode;
}

export function TextSection(props: TextSectionProps): React.ReactNode;
