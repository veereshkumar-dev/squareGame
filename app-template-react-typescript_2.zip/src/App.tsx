import React from 'react';
import './App.css';

import PDF from 'react-read-pdf';
import TextArea from './TextArea';
const { PDFReader } = PDF;

import './Libraries/uikit/dist/css/uikit.css';
import './Libraries/tailwind/tailwind.css';
import './Libraries/uikit/dist/js/uikit.js';
import SidePannel from './SidePannel';
import PDFSection from './PDFSection';
import TextSection from './TextSection';
import AppStore from './Store/AppStore';
import PopOver from './PopOver';

interface AppProps {}


function App({}: AppProps) {
  return (
    <div className="App uk-flex w-screen h-screen">
      <PDFSection/>
      <TextSection/>
      <SidePannel/>
      <PopOver/>
    </div>
  );
}

export default App;
