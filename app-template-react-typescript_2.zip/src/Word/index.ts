export { default } from "./Word";
