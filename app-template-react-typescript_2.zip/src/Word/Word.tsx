import React, { PureComponent } from 'react';
import './Word.scss';

import { WordProps } from './IWord';

import { observer } from 'mobx-react';

//import './Word.scss';

import Lib from '../Lib';
const { log, AppStore } = Lib;

@observer
export default class Word extends PureComponent<WordProps> {
  public render() {
    let { index, checkHighlight, isPageStart, pageNumber, text } = this.props;
    // log('word');

    return (
      <span
        key={index}
        onMouseDown={(e) => {
          AppStore.hidePopover();
          AppStore.recordStart(index);
          AppStore.recordStart_Mouse(e.pageX);
        }}
        onMouseUp={(e) => {
          //$('.popover').css({ top: e.pageY - 80, left: e.pageX });

          AppStore.setPopOverPosition(e.pageX, e.pageY);

          AppStore.recordEnd(index);
          AppStore.recordEnd_Mouse(e.pageX);

          // log(AppStore.newStartPosition, '--', AppStore.newEndPosition);
          if (AppStore.newStartPosition != AppStore.newEndPosition || AppStore.newStartPosition_Mouse != AppStore.newEndPosition_Mouse) {
            log('---> true');
               AppStore.showPopover();

            }
        }}
        {...(checkHighlight.includes('tokenStart') ||
        checkHighlight.includes('pageStart')
          ? {
              id: isPageStart
                ? 'pageStart' + pageNumber.toString()
                : checkHighlight.includes('tokenStart')
                ? 'frag' + checkHighlight.split('frag')[1]
                : '',
            }
          : {})}
        className={checkHighlight}
      >
        {text + ' '}
      </span>
    );
  }
}
