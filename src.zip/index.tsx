import './styles/index.css';

import React from 'react';
import ReactDOM from 'react-dom';
//import App from './App';
import App from './TextSection';


// Render App
ReactDOM.render(
  <App></App>,
  document.getElementById('root'),
);

if (import.meta.hot) {
  import.meta.hot.accept();
}
