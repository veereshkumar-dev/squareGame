import * as React from 'react';
import './styles/app.css'

import $ from 'jquery';
var jquery = $
window['$'] = $

export interface IAppProps {
}

import {
    action,
    computed,
    makeAutoObservable,
    makeObservable,
    observable,
    toJS
} from 'mobx';
import { observer } from 'mobx-react';

function isElementVisible(el) {
    var rect = el.getBoundingClientRect(),
        vWidth = window.innerWidth || document.documentElement.clientWidth,
        vHeight = window.innerHeight || document.documentElement.clientHeight,
        efp = function (x, y) { return document.elementFromPoint(x, y) };

    // Return false if it's not in the viewport
    if (rect.right < 0 || rect.bottom < 0
        || rect.left > vWidth || rect.top > vHeight)
        return false;

    // Return true if any of its four corners are visible
    return (
        el.contains(efp(rect.left, rect.top))
        || el.contains(efp(rect.right, rect.top))
        || el.contains(efp(rect.right, rect.bottom))
        || el.contains(efp(rect.left, rect.bottom))
    );
}

function inViewport(el) {

    var r, html;
    if (!el || 1 !== el.nodeType) { return false; }
    html = document.documentElement;
    r = el.getBoundingClientRect();

    return (!!r
        && r.bottom >= 0
        && r.right >= 0
        && r.top <= html.clientHeight
        && r.left <= html.clientWidth
    );

}


function areArraysEqualSets(a1, a2) {
    const superSet = {};
    for (const i of a1) {
        const e = i + typeof i;
        superSet[e] = 1;
    }

    for (const i of a2) {
        const e = i + typeof i;
        if (!superSet[e]) {
            return false;
        }
        superSet[e] = 2;
    }

    for (let e in superSet) {
        if (superSet[e] === 1) {
            return false;
        }
    }

    return true;
}


class Store {
    constructor() {
        makeAutoObservable(this);
    }

    @observable pdfObj: any = null

    @observable show = false;
    @observable text = 'loadin';
    @observable pageNumber = 1;
    @observable totalPages = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];

    @observable renderedPages = []
    @action setRenderedPages(pages) {
        this.renderedPages = [...pages]
    }

    @observable clearedPages = []
    @action setClearedPages(pages) {
        this.clearedPages = [...pages]
    }

    @observable changedPages = []
    @action setChangedPages(newChangedPages) {
        this.changedPages = [...newChangedPages]
    }

    @observable pagesInViewport = {

    }

    @action init() {
        this.totalPages.forEach(element => {
            let key = 'p' + element
            this.pagesInViewport[key] = {
                oldValue: false,
                newValue: false
            }
        });

        console.log(toJS(this.pagesInViewport))
    }


    @action
    changePage() {
        console.log('PageChanged');
        this.show = true;
        // this.pageNumber = 34;
    }
}

var url = 'http://localhost:8080/A17_FlightPlan.pdf';

// Loaded via <script> tag, create shortcut to access PDF.js exports.
var pdfjsLib = window['pdfjs-dist/build/pdf'];

//import pdfjs from 'node_modules/pdfjs-dist/build/pdf.js'

// The workerSrc property shall be specified.
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://mozilla.github.io/pdf.js/build/pdf.worker.js';

// var PDFJS = pdfjsLib

// console.log(PDFJS.getDocument)

@observer
export default class App extends React.Component<IAppProps> {
    store = new Store()

    componentDidMount() {
        this.store.init()
        // setTimeout(() => {
        //     this.store.changePage()
        // }, 2000);

        // console.log(pdfjsLib)
        // console.log(pdfjsLib.getDocument)

        var tt = pdfjsLib.getDocument('A17_FlightPlan.pdf')
        console.log('tt', tt)
        tt.promise.then((pdf) => {

            this.store.pdfObj = pdf
            // Using promise to fetch the page

        });
    }

    public render() {
        return (
            <div className="w-full flex">
                <div className=" pdfSection w-1/2 max-h-screen overflow-auto bg-white text-center items-center" onScroll={() => {
                    //console.log('scrollin')
                    if (!this.store.pdfObj) {
                        return
                    }
                    jquery('.page').map((item, el) => {
                        let key = 'p' + (item + 1)
                        if (inViewport(el)) {
                            if (this.store.pagesInViewport[key].newValue == false) {
                                this.store.pagesInViewport[key].newValue = true;
                                this.store.pagesInViewport[key].oldValue = false;
                            }
                            //console.log(item, key, el)
                        }
                        else {
                            this.store.pagesInViewport[key].newValue = false;
                        }
                    })

                    let changedPages = []

                    // console.log(toJS(this.store.pagesInViewport))
                    // console.log(changedPages)

                    this.store.totalPages.forEach(element => {
                        let key = 'p' + (element)
                        let currPage = this.store.pagesInViewport[key]
                        if (currPage.newValue != currPage.oldValue) {
                            changedPages.push(key)
                        }
                    });

                    if (changedPages.length > 0 && (this.store.changedPages.length == 0 || !areArraysEqualSets(changedPages, this.store.changedPages))) {
                        console.log(('--------'))
                        this.store.setChangedPages(changedPages)

                        console.log(changedPages)
                        console.log(toJS(this.store.changedPages))


                        let renderedPages2:string[] = []
                        this.store.changedPages.map((item, num) => {
                            let currentPageNumber = (parseInt(item.replace('p', '')))
                            let key = 'p' + currentPageNumber


                            this.store.pdfObj.getPage(currentPageNumber).then((page) => {
                                // if($('canvas#canvas-p'+currentPageNumber).length>0){
                                //     console.log('already rendered!!')
                                //     return
                                // }

                                if (this.store.renderedPages.includes(key)) {
                                    console.log('already rendered!!')
                                    return
                                }


                                var scale = 1.5;
                                var viewport = page.getViewport(1);

                                //
                                // Prepare canvas using PDF page dimensions
                                //
                                var canvas = document.getElementById('canvas-p' + currentPageNumber);
                                var context = canvas.getContext('2d');
                                canvas.height = 1027;
                                canvas.width = 622;

                                //
                                // Render PDF page into canvas context
                                //
                                var renderContext = {
                                    canvasContext: context,
                                    viewport: viewport
                                };
                                renderedPages2.push(key)

                                console.log('rendering page', currentPageNumber)
                        console.log('renderedPages',renderedPages2)

                                page.render(renderContext);
                            });

                        })

                        console.log('rendered b4', toJS(this.store.renderedPages))
                        console.log('renderedPages',renderedPages2)
                        this.store.setRenderedPages(renderedPages2)
                        console.log('rendered after', toJS(this.store.renderedPages))


                        // let clearedPages = []
                        // $('canvas').map((num,item)=>{
                        //     let currentCanvasPageNumber = parseInt(item.id.replace('canvas-p',''))
                        //     let key = 'p'+currentCanvasPageNumber

                        //     if(this.store.changedPages.includes(key)){
                        //         console.log('retu')
                        //         return
                        //     }
                        //     else{
                        //         console.log('enter')
                        //         clearedPages.push(key)
                        //         console.log('clearedPages', clearedPages)
                        //     }
                        // })

                        // this.store.setClearedPages(clearedPages)

                        // console.log('renderedPages', toJS(this.store.renderedPages))
                        // console.log('clearedPages',toJS(this.store.clearedPages))



                    }
                }}>
                    <div className="flex flex-col w-full overflow-auto" >
                        {this.store.totalPages.map(currentPage => {

                            let key = 'p' + currentPage
                            return <div id={key} key={key} className="page  h-screen m-3">
                                {this.store.changedPages.includes(key) ?
                                    (<canvas className="h-screen w-full" id={'canvas-p' + currentPage}></canvas>) :
                                    ('none')}

                            </div>
                        })}
                    </div>

                </div>
                <div className="textSection w-1/2 bg-blue-600 m-auto text-center">
                    <button className="w-1/2 m-2 border-2" onClick={() => {

                    }}>Whats in VIEWPORT</button>
                </div>
            </div>
        );
    }
}
