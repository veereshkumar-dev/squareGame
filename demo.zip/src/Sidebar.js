// @flow

import React from "react";

import type { T_Highlight } from "react-pdf-highlighter/src/types";
type T_ManuscriptHighlight = T_Highlight;

type Props = {
  highlights: Array<T_ManuscriptHighlight>,
  resetHighlights: () => void,
  toggleDocument: () => void,
  deleteSelection: ()=> void,
  metadata: Array<Object>,
  exportRows: Array<Object>,
};

const updateHash = highlight => {
  document.location.hash = `highlight-${highlight.id}`;
};

function exportToCsv(filename, rows) {
  var processRow = function (row) {
      var finalVal = '';
      for (var j = 0; j < row.length; j++) {
          var innerValue = row[j] === null ? '' : row[j].toString();
          if (row[j] instanceof Date) {
              innerValue = row[j].toLocaleString();
          };
          var result = innerValue.replace(/"/g, '""');
          if (result.search(/("|,|\n)/g) >= 0)
              result = '"' + result + '"';
          if (j > 0)
              finalVal += ',';
          finalVal += result;
      }
      return finalVal + '\n';
  };

  var csvFile = '';
  for (var i = 0; i < rows.length; i++) {
      csvFile += processRow(rows[i]);
  }

  var blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
  if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(blob, filename);
  } else {
      var link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
          // Browsers that support HTML5 download attribute
          var url = URL.createObjectURL(blob);
          link.setAttribute("href", url);
          link.setAttribute("download", filename);
          link.style.visibility = 'hidden';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
      }
  }
}

function Sidebar({ metadata,highlights,exportRows,deleteSelection, toggleDocument, resetHighlights }: Props) {
  return (
    <div className="sidebar" style={{ width: "25vw" }}>
      <div className="description" style={{ padding: "1rem" }}>
        <h2 style={{ marginBottom: "1rem" }}>Review Contract CDEs</h2>

       

      </div>

      <div style={{ padding: "1rem" }}>
        <button style={{ padding: "1rem" }} onClick={toggleDocument}>Review Next Contract</button>
        <button style={{ padding: "1rem", color: "white", background:"#0078d7" }} onClick={()=>{
          console.log(highlights)
          let rows = [
            ["Tag", "Selection"]
          ]
          highlights.map((item)=>{
            console.log(item)
            let row = [
              item.comment.text,
              item.content.text,
            ]
            rows.push(row)

          })
          console.log(rows)

          exportToCsv('AnnotatedData.csv', exportRows)
        }}>Export To File</button>
      </div>
      {/* {highlights.length > 0 ? (
        <div style={{ padding: "1rem" }}>
          <button onClick={resetHighlights}>Export Annotated Data</button>
        </div>
      ) : null} */}

      <h4 style={{ padding: "1rem" , paddingBottom:"0 !important", marginBottom:"0"}}>Contract Info</h4>
      <table style={{ padding: "1rem" , paddingTop:"0"}}> {metadata.map(el=>{
        return <tr><td style={{border:"solid thin #ddd", padding:"5px"}}>{el["Name"]}</td><td style={{border:"solid thin #ddd", padding:"5px"}}><span>{el["Value"]}</span></td></tr>
      })}</table>

      <ul className="sidebar__highlights">
        {highlights.map((highlight, index) => (
          <li
            key={index}
            className="sidebar__highlight"
            onClick={() => {
              updateHash(highlight);
            }}
          >
            <div>
              <strong>{highlight.comment.text}</strong>
              {highlight.content.text ? (
                <blockquote style={{ marginTop: "0.5rem" }}>
                  {`${highlight.content.text.slice(0, 90).trim()}…`}
                </blockquote>
              ) : null}
              {highlight.content.image ? (
                <div
                  className="highlight__image"
                  style={{ marginTop: "0.5rem" }}
                >
                  <img src={highlight.content.image} alt={"Screenshot"} />
                </div>
              ) : null}
            </div>
            <button className="highlight__location" 
            onClick={() => {
              deleteSelection(highlight);
            }}
            >
              X
               {/* {highlight.position.pageNumber} */}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Sidebar;
