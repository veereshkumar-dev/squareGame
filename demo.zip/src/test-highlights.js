const testHighlights = {
  // "https://arxiv.org/pdf/1708.08021.pdf": [
  //   {
  //     content: {
  //       text: " millions of lines of code atFacebookevery day"
  //     },
  //     position: {
  //       boundingRect: {
  //         x1: 139.20449829101562,
  //         y1: 410.4850769042969,
  //         x2: 320.2887878417969,
  //         y2: 424.2533874511719,
  //         width: 486.0,
  //         height: 720.0
  //       },
  //       rects: [
  //         {
  //           x1: 139.20449829101562,
  //           y1: 410.4850769042969,
  //           x2: 320.2887878417969,
  //           y2: 424.2533874511719,
  //           width: 486.0,
  //           height: 720.0
  //         }
  //       ],
  //       pageNumber: 3
  //     },
  //     comment: {
  //       text: "impressive",
  //       emoji: ""
  //     },
  //     id: "812807243318874"
  //   }
  // ],
  // "https://arxiv.org/pdf/1604.02480.pdf": [
  //   {
  //     content: {
  //       text: "SSA"
  //     },
  //     position: {
  //       boundingRect: {
  //         x1: 816.4599609375,
  //         y1: 360.1875,
  //         x2: 848.4677734375,
  //         y2: 380.1875,
  //         width: 1019.9999999999999,
  //         height: 1319.9999999999998
  //       },
  //       rects: [
  //         {
  //           x1: 816.4599609375,
  //           y1: 360.1875,
  //           x2: 848.4677734375,
  //           y2: 380.1875,
  //           width: 1019.9999999999999,
  //           height: 1319.9999999999998
  //         }
  //       ],
  //       pageNumber: 1
  //     },
  //     comment: {
  //       text: "Static Single Assignment",
  //       emoji: "😎"
  //     },
  //     id: "29668244118038056"
  //   }
  // ]
};

export default testHighlights;
