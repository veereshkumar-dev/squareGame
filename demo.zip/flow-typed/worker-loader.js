declare module 'worker-loader!pdfjs-dist/lib/pdf.worker' {
    declare module.exports: Worker;
}