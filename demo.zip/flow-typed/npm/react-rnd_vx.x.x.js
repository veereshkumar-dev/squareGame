declare module 'react-rnd' {
  declare module.exports: any;
}