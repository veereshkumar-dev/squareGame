module.exports = {
  verbose: true,
  preset: "jest-puppeteer"
};
