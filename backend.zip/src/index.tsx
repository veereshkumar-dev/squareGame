// const fastify = require('fastify')()
// const path = require('path')
// const moment = require('moment')
// const static = require('fastify-static');

// // We need to get the port that IISNode passes into us 
// // using the PORT environment variable, if it isn't set use a default value
const port = process.env.PORT || 3005;

// fastify.register(static, {
//   root:'/',
//   //prefix: '/assets/'
// });

// // Setup a route at the index of our app    
// fastify.get('/', function (req, res) {
//     return res.send('hh is working on IISNode!');
// });
'use strict'

const path = require('path')
const Handlebars = require('handlebars')

const fastify = require('fastify')({ logger: { level: 'trace' } })

// Handlebar template for listing files and directories.
const template = `
<html>
  <body>
    dirs
  <ul>
    {{#dirs}}
      <li><a href="{{href}}">{{name}}</a></li>
    {{/dirs}}
  </ul>
  list
  <ul>
    {{#files}}
      <li><a href="{{href}}" target="_blank">{{name}}</a></li>
    {{/files}}
  </ul>
  </body>
</html>
`
const handlebarTemplate = Handlebars.compile(template)
fastify.get('/backend', function (req, res) {
  return res.send('sup README.md');
});

fastify.get('/backend/kk', function (req, res) {
  //return res.download('README.md');
  return res.sendFile('README.md');
});

fastify.post('/backend/post', function (req, res) {
  //return res.download('README.md');
  return res.sendFile('README.md');
});

fastify
  .register(require('fastify-static'), {
    // An absolute path containing static files to serve.
    root: path.join(__dirname, '/'),

  })

  


  fastify.listen(port, err => {
    if (err) throw err
  })