# Template_NodeJS_Starter

Man i've done and redone this project so many times.. But everytime i misplaced it.. but tat ends today.!! This will be the perfect starting place for all my future NodeJS projects Thanks to my local GIT oh yea..!